﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class CollectionManipulation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Stack();
            Queue();
            LinkedList();
            SortedList();

        }

        protected void Stack()
        {

            // Declare the stack.
            Stack<String> strProductStack = new Stack<String>();

            // Add items to the stack.
            strProductStack.Push("Nike Men's Summer Flex Ace 7 Inch Short");
            strProductStack.Push("Nike Men's Summer RF Premier Jacket");
            strProductStack.Push("Nike Zoom Vapor 9.5 Tour");
            strProductStack.Push("Babolat Pure Aero French Open");
            // strProductStack [0] = "Babolat Pure Aero French Open" (Top)
            // strProductStack [1] = "Nike Zoom Vapor 9.5 Tour"
            // strProductStack [2] = "Nike Men's Summer RF Premier Jacket"
            // strProductStack [3] = "Nike Men's Summer Flex Ace 7 Inch Short"
            // (Bottom)

            // Get the number of items in the stack.
            Int32 i32Count = strProductStack.Count;
            // i32Count = 4

            // See what the next item on the stack is without removing it.
            String strProduct = "";
            strProduct = strProductStack.Peek();
            // strProduct = "Babolat Pure Aero French Open"
            // strProductStack [0] = "Babolat Pure Aero French Open" (Top)
            // strProductStack [1] = "Nike Zoom Vapor 9.5 Tour"
            // strProductStack [2] = "Nike Men's Summer RF Premier Jacket"
            // strProductStack [3] = "Nike Men's Summer Flex Ace 7 Inch Short"
            // (Bottom)

            // Remove an item from the stack.
            strProduct = strProductStack.Pop();
            // strProduct = "Babolat Pure Aero French Open"
            // strProductStack [0] = "Nike Zoom Vapor 9.5 Tour" (Top)
            // strProductStack [1] = "Nike Men's Summer RF Premier Jacket"
            // strProductStack [2] = "Nike Men's Summer Flex Ace 7 Inch Short"
            // (Bottom)

            // Clear the stack.
            strProductStack.Clear();
            // strProductStack = empty

        }

        protected void Queue()
        {

            // Declare the queue.
            Queue<String> strProductQueue = new Queue<String>();

            // Add items to the queue.
            strProductQueue.Enqueue("Nike Men's Summer Flex Ace 7 Inch Short");
            strProductQueue.Enqueue("Nike Men's Summer RF Premier Jacket");
            strProductQueue.Enqueue("Nike Zoom Vapor 9.5 Tour");
            strProductQueue.Enqueue("Babolat Pure Aero French Open");
            // strProductQueue [0] = "Nike Men's Summer Flex Ace 7 Inch Short" (Beg.)
            // strProductQueue [1] = "Nike Men's Summer RF Premier Jacket"
            // strProductQueue [2] = "Nike Zoom Vapor 9.5 Tour"
            // strProductQueue [3] = "Babolat Pure Aero French Open" (End)

            // Get the number of items in the queue.
            Int32 i32Count = strProductQueue.Count;
            // i32Count = 4

            // See what the next item in the queue is without removing it.
            String strProduct = "";
            strProduct = strProductQueue.Peek();
            // strProduct = "Nike Men's Summer Flex Ace 7 Inch Short"
            // strProductQueue [0] = "Nike Men's Summer Flex Ace 7 Inch Short" (Beg.)
            // strProductQueue [1] = "Nike Men's Summer RF Premier Jacket"
            // strProductQueue [2] = "Nike Zoom Vapor 9.5 Tour"
            // strProductQueue [3] = "Babolat Pure Aero French Open" (End)

            // Remove an item from the queue.
            strProduct = strProductQueue.Dequeue();
            // strProduct = "Nike Men's Summer Flex Ace 7 Inch Short"
            // strProductQueue [0] = "Nike Men's Summer RF Premier Jacket" (Beg.)
            // strProductQueue [1] = "Nike Zoom Vapor 9.5 Tour"
            // strProductQueue [2] = "Babolat Pure Aero French Open" (End)

            // Clear the queue.
            strProductQueue.Clear();
            // strProductQueue = empty

        }

        protected void LinkedList()
        {

            // Declare the linked list.
            LinkedList<String> strSupplierLinkedList = new LinkedList<String>();

            // Add a node to the beginning of the linked list.
            strSupplierLinkedList.AddFirst("Adidas");
            // strSupplierLinkedList [0] = "Adidas" (Start and End)

            // Add a node after the first node in the linked list.
            LinkedListNode<String> llnCurrentNode;
            llnCurrentNode = strSupplierLinkedList.First;
            strSupplierLinkedList.AddAfter(llnCurrentNode, "Babolat");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat" (End)

            // Add a node after the current node in the linked list.
            llnCurrentNode = strSupplierLinkedList.Find("Babolat");
            strSupplierLinkedList.AddAfter(llnCurrentNode, "Nike");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat"
            // strSupplierLinkedList [2] = "Nike" (End)

            // Add a node before the specified node in the linked list.
            llnCurrentNode = strSupplierLinkedList.Find("Nike");
            strSupplierLinkedList.AddBefore(llnCurrentNode, "Head");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat"
            // strSupplierLinkedList [2] = "Head"
            // strSupplierLinkedList [3] = "Nike" (End)

            // Add a node to the end of the linked list.
            strSupplierLinkedList.AddLast("Prince");
            // strSupplierLinkedList [0] = "Adidas" (Start)
            // strSupplierLinkedList [1] = "Babolat"
            // strSupplierLinkedList [2] = "Head"
            // strSupplierLinkedList [3] = "Nike"
            // strSupplierLinkedList [4] = "Prince" (End)

            // Get the number of nodes in the linked list.
            Int32 i32Count = strSupplierLinkedList.Count;
            // i32Count = 5

            // Get the first node of the linked list.
            String strSupplier = "";
            strSupplier = strSupplierLinkedList.First.Value;
            // strSupplier = "Adidas"

            // Get the last node of the linked list.
            strSupplier = strSupplierLinkedList.Last.Value;
            // strSupplier = "Prince"

            // Determine whether or not a value exists in the linked list.
            Boolean booFound = false;
            booFound = strSupplierLinkedList.Contains("Nike");
            // booFound = true

            // Find the first node in the linked list that contains the specified
            // value.
            String strCurrentNodeValue = "";
            llnCurrentNode = strSupplierLinkedList.Find("Head");
            strCurrentNodeValue = llnCurrentNode.Value;
            // llnCurrentNode = [3], strCurrentNodeValue = "Head"

            // Find the first node in the linked list that contains the specified
            // value. The specified value is not in the list.
            llnCurrentNode = strSupplierLinkedList.Find("xyz");
            // llnCurrentNode = null

            // Remove the node at the beginning of the linked list.
            strSupplierLinkedList.RemoveFirst();
            // strSupplierLinkedList [0] = "Babolat" (Start)
            // strSupplierLinkedList [1] = "Head"
            // strSupplierLinkedList [2] = "Nike"
            // strSupplierLinkedList [3] = "Prince" (End)

            // Remove the node at the end of the linked list.
            strSupplierLinkedList.RemoveLast();
            // strSupplierLinkedList [0] = "Babolat" (Start)
            // strSupplierLinkedList [1] = "Head"
            // strSupplierLinkedList [2] = "Nike" (End)

            // Remove the first occurrence of the specified value from the linked
            // list.
            strSupplierLinkedList.Remove("Head");
            // strSupplierLinkedList [0] = "Babolat" (Start)
            // strSupplierLinkedList [1] = "Nike" (End)

            // Clear the linked list.
            strSupplierLinkedList.Clear();
            // strSupplierLinkedList = empty

        }

        protected void SortedList()
        {

            // Declare the sorted list.
            SortedList<String, String> strShipperSortedList = new SortedList<String, String>();

            // Add an element with the specified key and value to the sorted list.
            strShipperSortedList.Add("FedEx", "Federal Express");
            strShipperSortedList.Add("DHL", "Dalsey, Hillblom, and Lynn");
            strShipperSortedList.Add("UPS", "United Parcel Service");
            strShipperSortedList.Add("USPS", "Un St Po Se");
            // strShipperSortedList [0] = {[DHL, Dalsey, Hillblom, and Lynn]} (Start)
            // strShipperSortedList [1] = {[FedEx, Federal Express]
            // strShipperSortedList [2] = {[UPS, United Parcel Service]}
            // strShipperSortedList [3] = {[USPS, Un St Po Se]} (End)

            // Get the number of elements in the sorted list.
            Int32 i32Count = strShipperSortedList.Count;
            // i32Count = 4

            // Set the value associated with a specific key in the sorted list.
            strShipperSortedList["USPS"] = "United States Postal Service";
            // strShipperSortedList [0] = {[DHL, Dalsey, Hillblom, and Lynn]} (Start)
            // strShipperSortedList [1] = {[FedEx, Federal Express]
            // strShipperSortedList [2] = {[UPS, United Parcel Service]}
            // strShipperSortedList [3] = {[USPS, United States Postal Service]} (End)

            // Get the value associated with a specific key in the sorted list.
            String strShipper = "";
            strShipper = strShipperSortedList["FedEx"];
            // strShipper = "Federal Express"

            // Determine whether or not the sorted list contains a specific key.
            Boolean booFound = false;
            booFound = strShipperSortedList.ContainsKey("UPS");
            // booFound = true

            // Determine whether or not the sorted list contains a specific value.
            booFound = strShipperSortedList.ContainsValue("United Parcel Service");
            // booFound = true

            // Remove the element with the specified key from the sorted list.
            strShipperSortedList.Remove("DHL");
            // strShipperSortedList [0] = {[FedEx, Federal Express] (Start)
            // strShipperSortedList [1] = {[UPS, United Parcel Service]}
            // strShipperSortedList [2] = {[USPS, United States Postal Service]} (End)

            // Clear the sorted list.
            strShipperSortedList.Clear();
            // strShipperSortedList = empty

        }

    }

}