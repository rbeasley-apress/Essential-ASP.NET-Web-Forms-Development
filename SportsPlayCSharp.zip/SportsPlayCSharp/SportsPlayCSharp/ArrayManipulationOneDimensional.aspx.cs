﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class ArrayManipulationOneDimensional : System.Web.UI.Page
    {

        // Declare a 3-element one-dimensional array of strings.
        String[] strShipperArray = new String[3];
        // strShipperArray[0] = null
        // strShipperArray[1] = null
        // strShipperArray[2] = null

        // Declare a 5-element one-dimensional array of strings.
        // Add items to the elements of the array upon initialization.
        String[] strCategoryArray = new String[5]
        {
            "Footwear - Men's", "Clothing - Men's", "Racquets",
            "Footwear - Women's", "Clothing - Women's"
        };
        // strCategoryArray[0] = "Footwear - Men's"
        // strCategoryArray[1] = "Clothing - Men's"
        // strCategoryArray[2] = "Racquets"
        // strCategoryArray[3] = "Footwear - Women's"
        // strCategoryArray[4] = "Clothing - Women's"

        protected void Page_Load(object sender, EventArgs e)
        {

            GettingNumberOfElements();
            SettingElementValuesUsingIndices();
            GettingElementValuesUsingIndices();
            SettingElementValuesUsingMethods();
            GettingElementValuesUsingMethods();
            CopyingElementValues();
            SortingElementValues();
            SearchingElementValues();
            ReversingElementValues();
            ClearingElementValues();

        }

        protected void GettingNumberOfElements()
        {

            // Get the total number of elements in the array.
            Int32 i32Length = strCategoryArray.Length;
            // i32Length = 5

        }

        protected void SettingElementValuesUsingIndices()
        {

            // Add values to the elements of the array.
            strCategoryArray[0] = "Footwear - Men's";
            strCategoryArray[1] = "Clothing - Men's";
            strCategoryArray[2] = "Racquets";
            strCategoryArray[3] = "Footwear - Women's";
            strCategoryArray[4] = "Clothing - Women's";
            // strCategoryArray[0] = "Footwear - Men's"
            // strCategoryArray[1] = "Clothing - Men's"
            // strCategoryArray[2] = "Racquets"
            // strCategoryArray[3] = "Footwear - Women's"
            // strCategoryArray[4] = "Clothing - Women's"

        }

        protected void SettingElementValuesUsingMethods()
        {

            // Add values to the elements of the array.
            strCategoryArray.SetValue("Footwear - Men's", 0);
            strCategoryArray.SetValue("Clothing - Men's", 1);
            strCategoryArray.SetValue("Racquets", 2);
            strCategoryArray.SetValue("Footwear - Women's", 3);
            strCategoryArray.SetValue("Clothing - Women's", 4);
            // strCategoryArray[0] = "Footwear - Men's"
            // strCategoryArray[1] = "Clothing - Men's"
            // strCategoryArray[2] = "Racquets"
            // strCategoryArray[3] = "Footwear - Women's"
            // strCategoryArray[4] = "Clothing - Women's"

        }

        protected void GettingElementValuesUsingIndices()
        {

            // Declare the variables.
            String strCategory = "";
            String strCategoryList = "";

            // Get the third element of the array.
            strCategory = strCategoryArray[2];
            // strCategory = "Racquets"

            // Get all the elements of the array and add them to the list using
            // a For structure.
            for (int i = 0; i < strCategoryArray.Length; i++)
            {
                strCategoryList = strCategoryList + strCategoryArray[i] + "; ";
            }
            // strCategoryList = "Footwear - Men's; Clothing - Men's; Racquets;
            // Footwear - Women's; Clothing - Women's; "

        }

        protected void GettingElementValuesUsingMethods()
        {

            // Declare the variables.
            String strCategory = "";
            String strCategoryList = "";

            // Get the third element of the array.
            strCategory = strCategoryArray.GetValue(2).ToString();
            // strCategory = "Racquets"

            // Get all the elements of the array and add them to the list using
            // a For structure.
            for (int i = 0; i < strCategoryArray.Length; i++)
            {
                strCategoryList = strCategoryList + strCategoryArray.GetValue(i) + "; ";
            }
            // strCategoryList = "Footwear - Men's; Clothing - Men's; Racquets;
            // Footwear - Women's; Clothing - Women's; "

        }

        protected void CopyingElementValues()
        {

            // Declare another 5-element one-dimensional array of strings.
            String[] strCategoryArrayCopy = new String[5];
            // Copy the elements from the original array to the element
            // values of the new array beginning at element [0] in both arrays
            // for the length of the original array.
            Array.Copy(strCategoryArray, 0, strCategoryArrayCopy, 0, strCategoryArray.Length);
            // strCategoryArrayCopy[0] = "Footwear - Men's"
            // strCategoryArrayCopy[1] = "Clothing - Men's"
            // strCategoryArrayCopy[2] = "Racquets"
            // strCategoryArrayCopy[3] = "Footwear - Women's"
            // strCategoryArrayCopy[4] = "Clothing - Women's"

        }

        protected void SortingElementValues()
        {

            // Sort the array.
            Array.Sort(strCategoryArray);
            // strCategoryArray[0] = "Clothing - Men's"
            // strCategoryArray[1] = "Clothing - Women's"
            // strCategoryArray[2] = "Footwear - Men's"
            // strCategoryArray[3] = "Footwear - Women's"
            // strCategoryArray[4] = "Racquets"

        }

        protected void SearchingElementValues()
        {

            // Declare the variables.
            Int32 i32Index = 0;
            Boolean booFound = false;

            // This is a sequential search.
            for (int i = 0; i < strCategoryArray.Length; i++)
            {
                if (strCategoryArray[i] == "Footwear - Women's")
                {
                    i32Index = i;
                    booFound = true;
                    break;
                }
            }
            // i32Index = 3, booFound = true

            // This is a binary search.
            i32Index = Array.BinarySearch(strCategoryArray, "Footwear - Women's");
            if (i32Index >= 0)
            {
                booFound = true;
            }
            // i32Index = 3, booFound = true

        }

        protected void ReversingElementValues()
        {

            // Reverse the array.
            Array.Reverse(strCategoryArray);
            // strCategoryArray[0] = "Racquets"
            // strCategoryArray[1] = "Footwear - Women's"
            // strCategoryArray[2] = "Footwear - Men's"
            // strCategoryArray[3] = "Clothing - Women's"
            // strCategoryArray[4] = "Clothing - Men's"

        }

        protected void ClearingElementValues()
        {

            // Clear elements 1 through 3.
            Array.Clear(strCategoryArray, 1, 3);
            // strCategoryArray[0] = "Racquets"
            // strCategoryArray[1] = null
            // strCategoryArray[2] = null
            // strCategoryArray[3] = null
            // strCategoryArray[4] = "Clothing - Men's"

        }

    }

}