﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SportsPlayCSharp.Classes
{
    public static class Password
    {

        public static String Generate(String strLastName, String strFirstName, Byte bytLength)
        {

            // Generate a password. The first two characters of the
            // password are the initials of the person's first and
            // last names. The last bytLength-2 characters of the
            // password are randomly generated.
            String strFirstNameInitial = strFirstName.Substring(0, 1).ToLower();
            String strLastNameInitial = strLastName.Substring(0, 1).ToLower();
            String strPassword = strFirstNameInitial + strLastNameInitial.ToString();
            Random ranRandom = new Random();
            for (int i = 1; i <= bytLength - 2; i++)
            {
                Int16 i16RandomNumber = (Int16)ranRandom.Next(1, 10);
                switch (i16RandomNumber)
                {
                    case 1:
                        strPassword = strPassword + "1";
                        break;
                    case 2:
                        strPassword = strPassword + "2";
                        break;
                    case 3:
                        strPassword = strPassword + "3";
                        break;
                    case 4:
                        strPassword = strPassword + "4";
                        break;
                    case 5:
                        strPassword = strPassword + "5";
                        break;
                    case 6:
                        strPassword = strPassword + "!";
                        break;
                    case 7:
                        strPassword = strPassword + "#";
                        break;
                    case 8:
                        strPassword = strPassword + "$";
                        break;
                    case 9:
                        strPassword = strPassword + "%";
                        break;
                    case 10:
                        strPassword = strPassword + "*";
                        break;
                }
            }
            return strPassword;

        }

    }

}