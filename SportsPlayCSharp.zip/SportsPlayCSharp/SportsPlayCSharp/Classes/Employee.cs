﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SportsPlayCSharp.Classes
{
    public class Employee
    {

        // Define the class's properties.
        public String LastName { set; get; }
        public String FirstName { set; get; }
        public String MiddleInitial { set; get; }
        public String Address { set; get; }
        public String City { set; get; }
        public String State { set; get; }
        public String ZipCode { set; get; }
        public String Phone { set; get; }
        public String EmailAddress { set; get; }
        public String Password { set; get; }

        public String GenerateEmailAddress(String strLastName, String strFirstName)
        {

            // Generate an email address.
            String strEmailAddress = strFirstName.Substring(0, 1).ToLower() + strLastName.ToLower() + "@sportsplay.com";
            return strEmailAddress;

        }

    }

}