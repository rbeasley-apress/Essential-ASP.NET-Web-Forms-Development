﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class Assignment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Declarations();
            Assignments();
            Enumerations();
            ExceptionHandling();

        }

        protected void Declarations()
        {

            // Declare Booleans.
            Boolean booPreferredCustomer = true;
            Boolean booOrderShipped = false;

            // Declare characters.
            Char[] chaZipCode = new Char[] { '4', '6', '1', '3', '1' };
            Char[] chaPrice = new Char[] { '$', '1', '9', '9', '.', '0', '0' };

            // Declare strings.
            String strSupplier = "";
            String strProduct = "Babolat Pure Aero French Open";

            // Declare numbers.
            Byte bytNumber = 10;
            Decimal decNumber = -10.00m;
            Double dblNumber = -10.00;
            Int16 i16Number = -10;
            Int32 i32Number = -10;
            Int64 i64Number = -10;
            SByte sbyNumber = -10;
            Single sinNumber = -10.12345f;
            UInt16 u16Number = 10;
            UInt32 u32Number = 10;
            UInt64 u64Number = 10;

            // Declare constants.
            const Byte bytDaysInJanuary = 31;
            const Decimal decSalesTaxRate = 0.07m;
            const String strLastNameLabel = "Last Name:";

        }

        protected void Assignments()
        {

            // Declare the variables.
            Double dblNumber1 = 0;
            Double dblNumber2 = 0;

            // This is a simple numeric assignment statement.
            dblNumber1 = 3;
            dblNumber2 = 7;
            dblNumber1 = dblNumber2;
            // dblNumber1 = 7

            // This is a compound numeric assignment statement that is
            // equivalent to dblNumber1 = dblNumber1 + dblNumber2.
            dblNumber1 = 3;
            dblNumber2 = 7;
            dblNumber1 += dblNumber2;
            // dblNumber1 = 10

            // This is a compound numeric assignment statement that is
            // equivalent to dblNumber1 = dblNumber1 - dblNumber2.
            dblNumber1 = 3;
            dblNumber2 = 7;
            dblNumber1 -= dblNumber2;
            // dblNumber1 = -4

            // This is a compound numeric assignment statement that is
            // equivalent to dblNumber1 = dblNumber1 * dblNumber2.
            dblNumber1 = 3;
            dblNumber2 = 7;
            dblNumber1 *= dblNumber2;
            // dblNumber1 = 21

            // This is a compound numeric assignment statement that is
            // equivalent to dblNumber1 = dblNumber1 / dblNumber2.
            dblNumber1 = 3;
            dblNumber2 = 7;
            dblNumber1 /= dblNumber2;
            // dblNumber1 = 0.42857142857142855

            // This is a compound numeric assignment statement that is
            // equivalent to dblNumber1 = dblNumber1 % dblNumber2.
            dblNumber1 = 3;
            dblNumber2 = 7;
            dblNumber1 %= dblNumber2;
            // dblNumber1 = 3

        }

        enum DiscountRate : Byte
        {

            Standard = 10,
            Select = 20,
            Preferred = 30

        }

        protected void Enumerations()
        {

            Byte bytCustomerDiscountRate = (Byte)DiscountRate.Preferred;
            // bytCustomerDiscountRate = 30

            String strCustomerType = DiscountRate.Preferred.ToString();
            // strCustomerType = "Preferred"

        }

        protected void ExceptionHandling()
        {

            // DivideNumber();
            CatchDivideByZeroException();
            CatchFormatException();
            CatchIndexOutOfRangeException();
            CatchOverflowException();
            CatchMultiplePossibleExceptions();

        }

        protected void DivideNumber()
        {

            // Divide the numerator by the denominator.
            Byte bytNumerator = 3;
            Byte bytDenominator = 0;
            Int32 i32Result = 0;
            i32Result = bytNumerator / bytDenominator;

        }

        protected void CatchDivideByZeroException()
        {

            // Check for a divide by zero exception.
            String strMessage = "";
            Byte bytNumerator = 3;
            Byte bytDenominator = 0;
            Int32 i32Result = 0;
            try
            {
                i32Result = bytNumerator / bytDenominator;
                strMessage = "The division was successful.";
            }
            catch (DivideByZeroException Exception)
            {
                strMessage = "The division was NOT successful. " + Exception.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The division was NOT successful. Attempted to
            // divide by zero. Thank you."

        }

        protected void CatchFormatException()
        {

            // Check for a format exception.
            String strMessage = "";
            txtNumber.Text = "abc";
            try
            {
                Byte bytNumber = Convert.ToByte(txtNumber.Text);
                strMessage = "The conversion was successful.";
            }
            catch (FormatException Exception)
            {
                strMessage = "The conversion was NOT successful. " + Exception.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The conversion was NOT successful. Input string was
            // not in a correct format. Thank you."

        }

        protected void CatchIndexOutOfRangeException()
        {

            // Check for an index out of range exception.
            String strMessage = "";
            String[] strNameArray = new String[] { "Bill", "Mary", "Steve" };
            try
            {
                String strName = strNameArray[5];
                strMessage = "The lookup was successful.";
            }
            catch (IndexOutOfRangeException Exception)
            {
                strMessage = "The lookup was NOT successful. " + Exception.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The lookup was NOT successful. Index was outside the
            // bounds of the array. Thank you."

        }

        protected void CatchOverflowException()
        {

            // Check for an overflow exception.
            String strMessage = "";
            Int32 i32Number = 256;
            Byte bytNumber = 0;
            try
            {
                bytNumber = Convert.ToByte(i32Number);
                strMessage = "The assignment was successful.";
            }
            catch (OverflowException Exception)
            {
                strMessage = "The assignment was NOT successful. " + Exception.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The assignment was NOT successful. Value was either
            // too large or too small for an unsigned byte. Thank you."

        }

        protected void CatchMultiplePossibleExceptions()
        {

            // Check for multiple possible exceptions.
            String strMessage = "";
            txtNumber.Text = "256";
            try
            {
                Byte bytNumber = Convert.ToByte(txtNumber.Text);
                strMessage = "The conversion and assignment were successful.";
            }
            catch (FormatException Exception)
            {
                strMessage = "The conversion was NOT successful. " + Exception.Message;
            }
            catch (OverflowException Exception)
            {
                strMessage = "The assignment was NOT successful. " + Exception.Message;
            }
            catch (Exception Exception)
            {
                strMessage = "Something else was NOT successful. " + Exception.Message;
            }
            finally
            {
                strMessage = strMessage + " Thank you.";
            }
            // strMessage = "The assignment was NOT successful. Value was either
            // too large or too small for an unsigned byte. Thank you."

        }

    }

}