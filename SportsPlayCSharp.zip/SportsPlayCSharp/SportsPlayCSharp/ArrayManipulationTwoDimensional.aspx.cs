﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class ArrayManipulationTwoDimensional : System.Web.UI.Page
    {

        // Declare a 3x2 6-element two-dimensional array of decimals.
        // There are three salespersons, and each salesperson has a
        // commission rate for non-equipment sales and equipment sales.
        Decimal[,] decCommissionRateArray = new Decimal[3, 2];
        // decCommissionRateArray[0, 0] = 0
        // decCommissionRateArray[0, 1] = 0
        // decCommissionRateArray[1, 0] = 0
        // decCommissionRateArray[1, 1] = 0
        // decCommissionRateArray[2, 0] = 0
        // decCommissionRateArray[2, 1] = 0

        // Declare a 3x7 21-element two-dimensional array of decimals.
        // Add items to the elements of the array upon initialization.
        // There are three salespersons, and each salesperson has
        // equipment sales for each day of the week (Sunday through Saturday).
        Decimal[,] decEquipmentSalesArray = new Decimal[3, 7]
        {
            { 0, 119.99m, 170.92m, 134.50m, 234.76m, 102.99m, 0 },
            { 145.78m, 200.12m, 409.11m, 102.99m, 189.99m, 209.34m, 379.99m },
            { 230.45m, 0, 0, 0, 0, 0, 172.65m },
        };
        // decEquipmentSalesArray[0, 0] = 0
        // decEquipmentSalesArray[0, 1] = 119.99
        // decEquipmentSalesArray[0, 2] = 170.92
        // ⁞
        // decEquipmentSalesArray[2, 4] = 0
        // decEquipmentSalesArray[2, 5] = 0
        // decEquipmentSalesArray[2, 6] = 172.65

        protected void Page_Load(object sender, EventArgs e)
        {

            GettingNumberOfElements();
            SettingElementValuesUsingIndices();
            GettingElementValuesUsingIndices();
            SettingElementValuesUsingMethods();
            GettingElementValuesUsingMethods();
            CopyingElementValues();
            SortingElementValues();
            SearchingElementValues();
            ReversingElementValues();
            ClearingElementValues();

        }

        protected void GettingNumberOfElements()
        {

            // Get the total number of elements in the array.
            Int32 i32Length = decEquipmentSalesArray.Length;
            // i32Length = 21

            // Get the total number of rows in the array.
            Int32 i32LengthRows = decEquipmentSalesArray.GetLength(0);
            // i32LengthRows = 3

            // Get the total number of columns in the array.
            Int32 i32LengthColumns = decEquipmentSalesArray.GetLength(1);
            // i32LengthColumns = 7

        }

        protected void SettingElementValuesUsingIndices()
        {

            // Add values to the elements of the array.
            decEquipmentSalesArray[0, 0] = 0;
            decEquipmentSalesArray[0, 1] = 119.99m;
            decEquipmentSalesArray[0, 2] = 170.92m;
            decEquipmentSalesArray[0, 3] = 134.50m;
            decEquipmentSalesArray[0, 4] = 234.76m;
            decEquipmentSalesArray[0, 5] = 102.99m;
            decEquipmentSalesArray[0, 6] = 0;
            decEquipmentSalesArray[1, 0] = 145.78m;
            decEquipmentSalesArray[1, 1] = 200.12m;
            decEquipmentSalesArray[1, 2] = 409.11m;
            decEquipmentSalesArray[1, 3] = 102.99m;
            decEquipmentSalesArray[1, 4] = 189.99m;
            decEquipmentSalesArray[1, 5] = 209.34m;
            decEquipmentSalesArray[1, 6] = 379.99m;
            decEquipmentSalesArray[2, 0] = 230.45m;
            decEquipmentSalesArray[2, 1] = 0;
            decEquipmentSalesArray[2, 2] = 0;
            decEquipmentSalesArray[2, 3] = 0;
            decEquipmentSalesArray[2, 4] = 0;
            decEquipmentSalesArray[2, 5] = 0;
            decEquipmentSalesArray[2, 6] = 172.65m;
            // decEquipmentSalesArray[0, 0] = 0
            // decEquipmentSalesArray[0, 1] = 119.99
            // decEquipmentSalesArray[0, 2] = 170.92
            // ⁞
            // decEquipmentSalesArray[2, 4] = 0
            // decEquipmentSalesArray[2, 5] = 0
            // decEquipmentSalesArray[2, 6] = 172.65

        }

        protected void SettingElementValuesUsingMethods()
        {

            // Add values to the elements of the array.
            decEquipmentSalesArray.SetValue(0m, 0, 0);
            decEquipmentSalesArray.SetValue(119.99m, 0, 1);
            decEquipmentSalesArray.SetValue(170.92m, 0, 2);
            decEquipmentSalesArray.SetValue(134.50m, 0, 3);
            decEquipmentSalesArray.SetValue(234.76m, 0, 4);
            decEquipmentSalesArray.SetValue(102.99m, 0, 5);
            decEquipmentSalesArray.SetValue(0m, 0, 6);
            decEquipmentSalesArray.SetValue(145.78m, 1, 0);
            decEquipmentSalesArray.SetValue(200.12m, 1, 1);
            decEquipmentSalesArray.SetValue(409.11m, 1, 2);
            decEquipmentSalesArray.SetValue(102.99m, 1, 3);
            decEquipmentSalesArray.SetValue(189.99m, 1, 4);
            decEquipmentSalesArray.SetValue(209.34m, 1, 5);
            decEquipmentSalesArray.SetValue(379.99m, 1, 6);
            decEquipmentSalesArray.SetValue(230.45m, 2, 0);
            decEquipmentSalesArray.SetValue(0m, 2, 1);
            decEquipmentSalesArray.SetValue(0m, 2, 2);
            decEquipmentSalesArray.SetValue(0m, 2, 3);
            decEquipmentSalesArray.SetValue(0m, 2, 4);
            decEquipmentSalesArray.SetValue(0m, 2, 5);
            decEquipmentSalesArray.SetValue(172.65m, 2, 6);
            // decEquipmentSalesArray[0, 0] = 0
            // decEquipmentSalesArray[0, 1] = 119.99
            // decEquipmentSalesArray[0, 2] = 170.92
            // ⁞
            // decEquipmentSalesArray[2, 4] = 0
            // decEquipmentSalesArray[2, 5] = 0
            // decEquipmentSalesArray[2, 6] = 172.65

        }

        protected void GettingElementValuesUsingIndices()
        {

            // Declare the variables.
            Decimal decEquipmentSales = 0;
            Decimal decEquipmentSalesTotal = 0;

            // Get the second row (sales person 2) third column (Wednesday) element
            // of the array.
            decEquipmentSales = decEquipmentSalesArray[1, 3];
            // decEquipmentSales = 102.99

            // Get all the elements of the array and sum them using a For structure.
            for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
            {
                for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
                {
                    decEquipmentSalesTotal = decEquipmentSalesTotal + decEquipmentSalesArray[i, j];
                }
            }
            // decEquipmentSalesTotal = 2803.58

        }

        protected void GettingElementValuesUsingMethods()
        {

            // Declare the variables.
            Decimal decEquipmentSales = 0;
            Decimal decEquipmentSalesTotal = 0;

            // Get the second row (sales person 2) third column (Wednesday) element
            // of the array.
            decEquipmentSales = (Decimal)decEquipmentSalesArray.GetValue(1, 3);
            // decEquipmentSales = 102.99

            // Get all the elements of the array and sum them using a For structure.
            for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
            {
                for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
                {
                    decEquipmentSalesTotal = decEquipmentSalesTotal + (Decimal)decEquipmentSalesArray.GetValue(i, j);
                }
            }
            // decEquipmentSalesTotal = 2803.58

        }

        protected void CopyingElementValues()
        {

            // Declare another 3x7 21-element two-dimensional array of decimals.
            Decimal[,] decEquipmentSalesArrayCopy = new Decimal[3, 7];
            // Copy the elements from the original array to the element
            // values of the new array beginning at element [0] in both arrays
            // for the length of the original array.
            Array.Copy(decEquipmentSalesArray, 0, decEquipmentSalesArrayCopy, 0, decEquipmentSalesArray.Length);
            // decEquipmentSalesArrayCopy[0, 0] = 0
            // decEquipmentSalesArrayCopy[0, 1] = 119.99
            // decEquipmentSalesArrayCopy[0, 2] = 170.92
            // ⁞
            // decEquipmentSalesArrayCopy[2, 4] = 0
            // decEquipmentSalesArrayCopy[2, 5] = 0
            // decEquipmentSalesArrayCopy[2, 6] = 172.65

        }

        protected void SortingElementValues()
        {

            // Not providing an example.

        }

        protected void SearchingElementValues()
        {

            // Declare the variables.
            Int32 i32IndexI = 0;
            Int32 i32IndexJ = 0;
            Boolean booFound = false;

            // This is a sequential search.
            for (int i = 0; i < decEquipmentSalesArray.GetLength(0); i++)
            {
                for (int j = 0; j < decEquipmentSalesArray.GetLength(1); j++)
                {
                    if (decEquipmentSalesArray[i, j] == 409.11m)
                    {
                        i32IndexI = i;
                        i32IndexJ = j;
                        booFound = true;
                        break;
                    }
                }
                if(booFound)
                {
                    break;
                }
            }
            // i32IndexI = 1, i32IndexJ = 2, booFound = true

        }

        protected void ReversingElementValues()
        {

            // Not providing an example.

        }

        protected void ClearingElementValues()
        {

            // Not providing an example.

        }

    }

}