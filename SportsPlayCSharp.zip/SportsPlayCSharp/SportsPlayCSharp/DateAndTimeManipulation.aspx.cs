﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class DateAndTimeManipulation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            DateProperties();
            DateMethods();
            DateFormatting();
            DateParsing();
            TimeProperties();
            TimeMethods();
            TimeFormatting();

        }

        protected void DateProperties()
        {

            // Get today's date.
            String strDate = DateTime.Today.ToString();
            // strDate = "7/18/2017 12:00:00 AM"

            // Get the year.
            Int32 i32Year = DateTime.Today.Year;
            // i32Year = 2017

            // Get the month.
            Int32 i32Month = DateTime.Today.Month;
            // i32Month = 7

            // Get the day.
            Int32 i32Day = DateTime.Today.Day;
            // i32Day = 18

            // Get the day of the week.
            String strDayOfWeek = DateTime.Today.DayOfWeek.ToString();
            // strDayOfWeek = "Tuesday"

            // Get the day of the year.
            Int32 i32DayOfYear = DateTime.Today.DayOfYear;
            // i32DayOfYear = 199

        }

        protected void DateMethods()
        {

            // Create a new DateTime structure.
            DateTime datDateCurrent = new DateTime();
            datDateCurrent = DateTime.Today;
            // datDateCurrent = {7/18/2017 12:00:00 AM}
            String strDateNew = "";
            // strDateNew = ""

            // Add 1 year to the current date.
            strDateNew = datDateCurrent.AddYears(1).ToString();
            // strDateNew = "7/18/2018 12:00:00 AM"

            // Add 3 months to the current date.
            strDateNew = datDateCurrent.AddMonths(3).ToString();
            // strDateNew = "10/18/2017 12:00:00 AM"

            // Add 5 days to the current date.
            strDateNew = datDateCurrent.AddDays(5).ToString();
            // strDateNew = "7/23/2017 12:00:00 AM"

            // Compare the current date to the first-of-year date.
            // Less than zero = The current date is earlier than the first-of-year
            // date.
            // Zero = The current date is the same as the first-of-year date.
            // Greater than zero = The current date is later than the first-of-year
            // date.
            DateTime datDateFirstOfYear = new DateTime(2017, 01, 01);
            Int32 i32Result = datDateCurrent.CompareTo(datDateFirstOfYear);
            // i32Result = 1

            // Check to see if daylight saving time is in effect.
            Boolean booDaylightSavingTime = datDateCurrent.IsDaylightSavingTime();
            // booDaylightSavingTime = true

            // Check to see if this is a leap year.
            Boolean booLeapYear = DateTime.IsLeapYear(datDateCurrent.Year);
            // booLeapYear = false

            // Determine how many days have elapsed since the first-of-year date
            // using a TimeSpan structure.
            TimeSpan timTimeSpan = datDateCurrent.Subtract(datDateFirstOfYear);
            Int32 i32DifferenceDays = timTimeSpan.Days;
            // i32DifferenceDays = 198

        }

        protected void DateFormatting()
        {

            // Declare the date string.
            String strDateNew = "";

            // Format the date as a long date.
            strDateNew = DateTime.Today.ToLongDateString();
            // strDateNew = "Tuesday, July 18, 2017"

            // Format the date as a short date.
            strDateNew = DateTime.Today.ToShortDateString();
            // strDateNew = "7/18/2017"

            // Customize the date using format specifiers.
            strDateNew = DateTime.Today.ToString("yyyy.MM.dd");
            // strDateNew = "2017.07.18"

            // Customize the date using format specifiers.
            strDateNew = DateTime.Today.ToString("dddd, MMMM dd, yyyy g");
            // strDateNew = "Tuesday, July 18, 2017 A.D."

        }

        protected void DateParsing()
        {

            // Declare the date structure and variables.
            DateTime datDate = new DateTime();
            String strDate = "";
            Boolean booSuccessful = false;

            // Attempt to parse a valid date (with dashes) from a string.
            // Check to make sure the parse was successful.
            strDate = "02-28-2017";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {2/28/2017 12:00:00 AM}, booSuccessful = true

            // Attempt to parse a valid date (with slashes) from a string.
            // Check to make sure the parse was successful.
            strDate = "02/28/2017";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {2/28/2017 12:00:00 AM}, booSuccessful = true

            // Attempt to parse a valid date (written out) from a string.
            // Check to make sure the parse was successful.
            strDate = "February 28, 2017";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {2/28/2017 12:00:00 AM}, booSuccessful = true

            // Attempt to parse an invalid date from a string. Check to make
            // sure the parse was successful.
            strDate = "02-29-2017";
            booSuccessful = DateTime.TryParse(strDate, out datDate);
            // datDate = {1/1/0001 12:00:00 AM}, booSuccessful = false

        }

        protected void TimeProperties()
        {

            // Get today's date and time.
            String strDateTime = DateTime.Now.ToString();
            // strDateTime = "7/18/2017 10:09:08 AM"

            // Hardcode the date and time for the following examples.
            DateTime datTimeCurrent = new DateTime(2017, 7, 18, 15, 30, 25);
            // datTimeCurrent = {7/18/2017 3:30:25 PM}

            // Get the time of day.
            String strTimeOfDay = datTimeCurrent.TimeOfDay.ToString();
            // strTimeOfDay = "15:30:25"

            // Get the hour.
            Int32 i32Hour = datTimeCurrent.Hour;
            // i32Hour = 15

            // Get the minute.
            Int32 i32Minute = datTimeCurrent.Minute;
            // i32Minute = 30

            // Get the second.
            Int32 i32Second = datTimeCurrent.Second;
            // i32Second = 25

        }

        protected void TimeMethods()
        {

            // Hardcode the date and time for the following examples.
            DateTime datTimeCurrent = new DateTime(2017, 7, 18, 15, 30, 25);
            // datTimeCurrent = {7/18/2017 3:30:25 PM}
            String strTimeNew = "";
            // strTimeNew = ""

            // Add 2 hours to the current time.
            strTimeNew = datTimeCurrent.AddHours(2).ToString();
            // strTimeNew = "7/18/2017 5:30:25 PM"

            // Add 4 minutes to the current time.
            strTimeNew = datTimeCurrent.AddMinutes(4).ToString();
            // strTimeNew = "7/18/2017 3:34:25 PM"

            // Add 6 seconds to the current time.
            strTimeNew = datTimeCurrent.AddSeconds(6).ToString();
            // strTimeNew = "7/18/2017 3:30:31 PM"

            // Compare the first time to the second time.
            // Less than zero = The first time is earlier than the second time.
            // Zero = The first is the same as the second time.
            // Greater than zero = The first time is later than the second time.
            DateTime datTimeFirst = new DateTime(2017, 7, 18, 12, 25, 30);
            DateTime datTimeSecond = new DateTime(2017, 7, 18, 11, 30, 25);
            Int32 i32Result = datTimeFirst.CompareTo(datTimeSecond);
            // i32Result = 1

            // Determine how many hours, minutes, and seconds have elapsed
            // since the first-of-year date using a TimeSpan structure.
            DateTime datDateFirstOfYear = new DateTime(2017, 01, 01);
            DateTime datDateCurrent = new DateTime();
            datDateCurrent = DateTime.Today;
            // datDateCurrent = {7/18/2017 12:00:00 AM}
            TimeSpan timTimeSpan = datDateCurrent.Subtract(datDateFirstOfYear);
            Double dblDifferenceHours = timTimeSpan.TotalHours;
            // dblDifferenceHours = 4752
            Double dblDifferenceMinutes = timTimeSpan.TotalMinutes;
            // dblDifferenceMinutes = 285120
            Double dblDifferenceSeconds = timTimeSpan.TotalSeconds;
            // dblDifferenceSeconds = 17107200

        }

        protected void TimeFormatting()
        {

            // Hardcode the date and time for the following examples.
            DateTime datTimeCurrent = new DateTime(2017, 7, 18, 15, 30, 25);
            // datTimeCurrent = {7/18/2017 3:30:25 PM}
            String strTimeNew = "";
            // strTimeNew = ""

            // Format the time as a long time.
            strTimeNew = datTimeCurrent.ToLongTimeString();
            // strTimeNew = "3:30:25 PM"

            // Format the time as a short time.
            strTimeNew = datTimeCurrent.ToShortTimeString();
            // strTimeNew = "3:30 PM"

            // Customize the time format without escape sequences.
            strTimeNew = datTimeCurrent.ToString("HH Hours mm Minutes ss Seconds");
            // strTimeNew = "15 15our25 30 7inuPe25 25 Secon1825"

            // Customize the time format with escape sequences.
            strTimeNew = datTimeCurrent.ToString("HH \\Hour\\s mm \\Minu\\te\\s ss \\Secon\\d\\s");
            // strTimeNew = "15 Hours 30 Minutes 25 Seconds"

            // Customize the time format without escape sequences.
            // ***** Commented out since exception is thrown. Uncomment out for use in book.
            // strTimeNew = datTimeCurrent.ToString("h:mm O'clock tt");
            // *****
            // Format exception is thrown. Cannot find a matching quote character
            // for the character '''.

            // Customize the time format with escape sequences.
            strTimeNew = datTimeCurrent.ToString("h:mm O\\'clock tt");
            // strTimeNew = "3:30 O'clock PM"

        }

    }

}