﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class LogicControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            IfStructure();
            IfElseStructure();
            IfElseIfStructure();
            NestedIfStructure();
            SwitchStructure();
            SwitchThroughStructure();
            WhileStructure();
            DoWhileStructure();
            ForStructure();
            ForEachStructure();
            BreakStatement();
            ContinueStatement();

        }

        protected void IfStructure()
        {

            // This is a relational operator example.

            // Declare the variables.
            const Double dblDiscountRateSenior = 0.10;
            Double dblSubtotal = 100.00;
            Byte bytCustomerAge = 55;

            // If the customer is 55 or older, apply the senior discount.
            if (bytCustomerAge >= 55)
            {
                dblSubtotal = dblSubtotal * (1 - dblDiscountRateSenior);
            }
            // dblSubtotal = 90

            // This is an equality operator example.

            // Declare the variables.
            Int32 i32ProductID = 5;
            String strMessage = "";

            // If the Product ID is 2, put out a message.
            if (i32ProductID == 2)
            {
                strMessage = "Sorry. That product is currently on backorder.";
            }
            // strMessage = ""

            // This is a logical OR operator example.

            // Declare the variables.
            String strZipCode = "46131";
            Boolean booDeliveryAvailable = false;

            // If the zip code is 46131 or 46132, indicate that delivery service
            // is available.
            if (strZipCode == "46131" | strZipCode == "46132")
            {
                booDeliveryAvailable = true;
            }
            // booDeliveryAvailable = true

            // This is a conditional AND operator example.

            // Declare the variables.
            Byte bytNumberInStock = 4;
            Byte bytNumberOnOrder = 0;
            Byte bytReorderLevel = 5;
            Boolean booReorderProduct = false;

            // If the number in stock is less than or equal to the reorder level,
            // and if there is nothing already on order, then set the number on order
            // to the reorder level and indicate that the product should be reordered.
            if (bytNumberInStock <= bytReorderLevel && bytNumberOnOrder == 0)
            {
                bytNumberOnOrder = bytReorderLevel;
                booReorderProduct = true;
            }
            // bytNumberOnOrder = 5, booReorderProduct = true

        }

        protected void IfElseStructure()
        {

            // Declare the variables.
            const Double dblSalesTaxRate = 0.7;
            Double dblSubtotal = 100.00;
            Double dblTotal = 0;
            String strState = "OH";

            // Only apply sales tax if the customer resides in Indiana.
            if (strState == "IN")
            {
                dblTotal = dblSubtotal + (dblSalesTaxRate * 10);
            }
            else
            {
                dblTotal = dblSubtotal;
            }
            // dblTotal = 100

        }

        protected void IfElseIfStructure()
        {

            // Declare the variables.
            const Double dblDiscountRateStandard = 0.10;
            const Double dblDiscountRateSelect = 0.20;
            const Double dblDiscountRatePreferred = 0.30;
            Double dblSubtotal = 100;
            String strCustomerType = "Select";

            // Apply the discount rate based on the type of customer.
            if (strCustomerType == "Standard")
            {
                dblSubtotal = dblSubtotal * (1 - dblDiscountRateStandard);
            }
            else if (strCustomerType == "Select")
            {
                dblSubtotal = dblSubtotal * (1 - dblDiscountRateSelect);
            }
            else if (strCustomerType == "Preferred")
            {
                dblSubtotal = dblSubtotal * (1 - dblDiscountRatePreferred);
            }
            else
            {
                // Do not apply a discount.
            }
            // dblSubtotal = 80

        }

        protected void NestedIfStructure()
        {

            // Declare the variables.
            const Double dblDiscountRateSenior = 0.10;
            const Double dblDiscountRateStandard = 0.10;
            const Double dblDiscountRateSelect = 0.20;
            const Double dblDiscountRatePreferred = 0.30;
            Double dblSubtotal = 100;
            Byte bytCustomerAge = 60;
            String strCustomerType = "Preferred";

            // If the customer is 55 or older, apply the senior discount.
            if (bytCustomerAge >= 55)
            {
                // Apply the discount rate based on the type of customer.
                if (strCustomerType == "Standard")
                {
                    dblSubtotal = dblSubtotal * (1 - (dblDiscountRateStandard + dblDiscountRateSenior));
                }
                else if (strCustomerType == "Select")
                {
                    dblSubtotal = dblSubtotal * (1 - (dblDiscountRateSelect + dblDiscountRateSenior));
                }
                else if (strCustomerType == "Preferred")
                {
                    dblSubtotal = dblSubtotal * (1 - (dblDiscountRatePreferred + dblDiscountRateSenior));
                }
                else
                {
                    // Do not apply a discount.
                }
            }
            else
            {
                // Apply the discount rate based on the type of customer.
                if (strCustomerType == "Standard")
                {
                    dblSubtotal = dblSubtotal * (1 - dblDiscountRateStandard);
                }
                else if (strCustomerType == "Select")
                {
                    dblSubtotal = dblSubtotal * (1 - dblDiscountRateSelect);
                }
                else if (strCustomerType == "Preferred")
                {
                    dblSubtotal = dblSubtotal * (1 - dblDiscountRatePreferred);
                }
                else
                {
                    // Do not apply a discount.
                }
            }
            // dblSubtotal = 60

        }

        protected void SwitchStructure()
        {

            // Declare the variables.
            const Double dblDiscountRateStandard = 0.10;
            const Double dblDiscountRateSelect = 0.20;
            const Double dblDiscountRatePreferred = 0.30;
            Double dblSubtotal = 100;
            String strCustomerType = "Standard";

            // Apply the discount rate based on the type of customer.
            switch (strCustomerType)
            {
                case "Standard":
                    dblSubtotal = dblSubtotal * (1 - dblDiscountRateStandard);
                    break;
                case "Select":
                    dblSubtotal = dblSubtotal * (1 - dblDiscountRateSelect);
                    break;
                case "Preferred":
                    dblSubtotal = dblSubtotal * (1 - dblDiscountRatePreferred);
                    break;
                default:
                    // Do not apply a discount.
                    break;
            }
            // dblSubtotal = 90

        }

        protected void SwitchThroughStructure()
        {

            // Declare the variables.
            Double dblSubtotal = 100;
            Double dblDiscountRate = 0;
            Byte bytNumberOfOrderLines = 5;

            // If the customer purchases 1-3 items, do not apply a discount.
            // If the customer purchases 4-6 items, apply a 10% discount.
            // If the customer purchases 7-9 items, apply a 20% discount.
            // If the customer purchases 10 or more items, apply a 30% discount.
            switch (bytNumberOfOrderLines)
            {
                case 1:
                case 2:
                case 3:
                    // Do not apply a discount.
                    break;
                case 4:
                case 5:
                case 6:
                    dblDiscountRate = 0.10;
                    break;
                case 7:
                case 8:
                case 9:
                    dblDiscountRate = 0.20;
                    break;
                default:
                    dblDiscountRate = 0.30;
                    break;
            }
            dblSubtotal = dblSubtotal * (1 - dblDiscountRate);
            // dblSubtotal = 90, dblDiscountRate = 0.1

        }

        protected void WhileStructure()
        {

            // Define an array of customers.
            String[] strCustomerArray = new String[] {"Davis, Dan", "Jones, Jerry", "Smith, Sally"};
            Int16 i16Index = 0;
            String strCustomerList = "";

            // Add customers to the customer list while i16Index is less than or equal to 2.
            while (i16Index <= 2)
            {
                strCustomerList = strCustomerList + strCustomerArray[i16Index] + "; ";
                i16Index++;
            }
            // strCustomerList = "Davis, Dan; Jones, Jerry; Smith, Sally; "

        }

        protected void DoWhileStructure()
        {

            // Define an array of customers.
            String[] strCustomerArray = new String[] { "Davis, Dan", "Jones, Jerry", "Smith, Sally" };
            Int16 i16Index = 0;
            String strCustomerList = "";

            // Add customers to the customer list until i16Index is less than or equal to 0.
            do
            {
                strCustomerList = strCustomerList + strCustomerArray[i16Index] + "; ";
                i16Index++;
            } while (i16Index <= 0);
            // strCustomerList = "Davis, Dan; "

        }

        protected void ForStructure()
        {

            // Define an array of suppliers.
            String[] strSupplierArray = new String[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            String strSupplierList = "";

            // Add suppliers to the supplier list while i is less than or equal to 4.
            for (Int16 i = 0; i <= 4; i++)
            {
                strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
            }
            // strSupplierList = "Adidas; Babolat; Head; Nike; Prince; "

        }

        protected void ForEachStructure()
        {

            // Define an array of suppliers.
            String[] strSupplierArray = new String[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            String strSupplierList = "";

            // Add suppliers to the supplier list while suppliers remain in the array.
            foreach (String strSupplier in strSupplierArray)
            {
                strSupplierList = strSupplierList + strSupplier + "; ";
            }
            // strSupplierList = "Adidas; Babolat; Head; Nike; Prince; "

        }

        protected void BreakStatement()
        {

            // Define an array of suppliers.
            String[] strSupplierArray = new String[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            String strSupplierList = "";

            // Add suppliers to the supplier list while i is less than or equal to 4
            // or until 3 suppliers have been added to the supplier list.
            for (Int16 i = 0; i <= 4; i++)
            {
                if (i <= 2)
                {
                    strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
                }
                else
                {
                    break;
                }
            }
            // strSupplierList = "Adidas; Babolat; Head; "

        }

        protected void ContinueStatement()
        {

            // Define an array of suppliers.
            String[] strSupplierArray = new String[] { "Adidas", "Babolat", "Head", "Nike", "Prince" };
            String strSupplierList = "";

            // Add every other supplier to the supplier list while i is less than or
            // equal to 4.
            for (Int16 i = 0; i <= 4; i++)
            {
                if (i % 2 == 0)
                {
                    strSupplierList = strSupplierList + strSupplierArray[i] + "; ";
                }
                else
                {
                    continue;
                }
            }
            // strSupplierList = "Adidas; Head; Prince; "

        }

    }

}