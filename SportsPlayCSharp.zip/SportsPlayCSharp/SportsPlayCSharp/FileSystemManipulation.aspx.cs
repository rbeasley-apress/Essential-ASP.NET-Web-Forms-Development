﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace SportsPlayCSharp
{
    public partial class FileSystemManipulation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            CreateFile();
            WriteToFile();
            ReadFromFile();
            DeleteFile();
            GetAndSetPropertiesAndAttributesOfFile();
            CopyFile();

        }

        protected void CreateFile()
        {

            // Create the file.
            String strMessage = "";
            String strFileName = "Contract_Adidas.txt";
            String strFilePath = Request.PhysicalApplicationPath + "Contracts\\" + strFileName;
            if (File.Exists(strFilePath))
            {
                strMessage = "That file name already exists.";
            }
            else
            {
                File.Create(strFilePath);
                strMessage = "Contract file successfully created.";
            }
            // strMessage = "Contract file successfully created."

        }

        protected void WriteToFile()
        {

            // Write to the file.
            String strFileName = "Contract_Adidas.txt";
            String strFilePath = Request.PhysicalApplicationPath + "Contracts\\" + strFileName;
            String strContract = "";
            strContract = "AGREEMENT BETWEEN SportsPlay AND Adidas" + Environment.NewLine + Environment.NewLine;
            strContract += "This Deed of Agreement is made and entered into on the 4th day of July 20xx" + Environment.NewLine + Environment.NewLine;
            strContract += "BETWEEN" + Environment.NewLine + Environment.NewLine;
            strContract += "SportsPlay, Inc. (hereinafter referred to as the PURCHASER)" + Environment.NewLine + Environment.NewLine;
            strContract += "AND" + Environment.NewLine + Environment.NewLine;
            strContract += "Adidas, Inc. (hereinafter referred to as the SUPPLIER).";
            File.AppendAllText(strFilePath, strContract);

        }

        protected void ReadFromFile()
        {

            // Read from the file.
            String strFileName = "Contract_Adidas.txt";
            String strFilePath = Request.PhysicalApplicationPath + "Contracts\\" + strFileName;
            String strContract = "";
            strContract = File.ReadAllText(strFilePath);
            // strContract =
            // AGREEMENT BETWEEN SportsPlay AND Adidas
            // 
            // This Deed of Agreement is made and entered into on the 4th day of July 20xx
            // 
            // BETWEEN
            // 
            // SportsPlay, Inc. (hereinafter referred to as the PURCHASER)
            // 
            // AND
            // 
            // Adidas, Inc. (hereinafter referred to as the SUPPLIER).

        }

        protected void DeleteFile()
        {

            // Delete the file.
            String strMessage = "";
            String strFileName = "Contract_Adidas.txt";
            String strFilePath = Request.PhysicalApplicationPath + "Contracts\\" + strFileName;
            if (File.Exists(strFilePath))
            {
                File.Delete(strFilePath);
                strMessage = "Contract file successfully deleted.";
            }
            else
            {
                strMessage = "Contract file NOT successfully deleted.";
            }
            // strMessage = "Contract file successfully deleted."

        }

        protected void GetAndSetPropertiesAndAttributesOfFile()
        {

            // Get and set the attributes and properties of the file.
            String strFileName = "Contract_Adidas.txt";
            String strFilePath = Request.PhysicalApplicationPath + "Contracts\\" + strFileName;

            // Get the date and time properties of the file.
            DateTime datCreated = File.GetCreationTime(strFilePath);
            // datCreated = {7/26/2017 2:27:00 PM}
            DateTime datModified = File.GetLastWriteTime(strFilePath);
            // datCreated = {7/26/2017 2:37:00 PM}
            DateTime datAccessed = File.GetLastAccessTime(strFilePath);
            // datCreated = {7/26/2017 2:37:00 PM}

            // Set the date and time properties of the file.
            File.SetCreationTime(strFilePath, DateTime.Now);
            File.SetLastWriteTime(strFilePath, DateTime.Now);
            File.SetLastAccessTime(strFilePath, DateTime.Now);

            // Get the read-only and hidden attributes of the file.
            FileAttributes fiaFileAttributes = File.GetAttributes(strFilePath);
            Boolean booReadOnly = (fiaFileAttributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly;
            Boolean booHidden = (fiaFileAttributes & FileAttributes.Hidden) == FileAttributes.Hidden;

            // Toggle (i.e., make opposite) the read-only and hidden attributes of
            // the file based on their current state.
            if (booReadOnly && booHidden)
            {
                // Make file not read-only and not hidden.
                File.SetAttributes(strFilePath, FileAttributes.Normal | FileAttributes.Normal);
            }
            else if (booReadOnly && !booHidden)
            {
                // Make file not read-only and hidden.
                File.SetAttributes(strFilePath, FileAttributes.Normal | FileAttributes.Hidden);
            }
            else if (!booReadOnly && booHidden)
            {
                // Make file read-only and not hidden.
                File.SetAttributes(strFilePath, FileAttributes.ReadOnly | FileAttributes.Normal);
            }
            else
            {
                // Make file read-only and hidden.
                File.SetAttributes(strFilePath, FileAttributes.ReadOnly  | FileAttributes.Hidden);
            }

        }

        protected void CopyFile()
        {

            // Make a copy of the file.
            String strFileName = "Contract_Adidas.txt";
            String strFileNameCopy = "Contract_Adidas_Copy.txt";
            String strFilePath = Request.PhysicalApplicationPath + "Contracts\\";
            File.Copy(strFilePath + strFileName, strFilePath + strFileNameCopy);

        }

    }

}