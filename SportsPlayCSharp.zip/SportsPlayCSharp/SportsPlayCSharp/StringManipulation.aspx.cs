﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class StringManipulation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Concatenations();
            EscapeSequences();
            VerbatimLiterals();
            StringClassProperties();
            StringClassMethods();

        }

        protected void Concatenations()
        {

            // Concatenate three strings.
            String strLastName = "Billingsley";
            String strFirstName = "Beth";
            String strMiddleInitial = "B";
            String strFullName = strFirstName + " " + strMiddleInitial + " " + strLastName;
            // strFullName = "Beth B Billingsley"

            // Append seven strings using the += operator.
            String strAddress = "6785 Barker Rd.";
            String strCity = "Bickman";
            String strState = "MS";
            String strZipCode = "68321";
            String strFullAddress = "";
            strFullAddress += strAddress;
            strFullAddress += " ";
            strFullAddress += strCity;
            strFullAddress += ", ";
            strFullAddress += strState;
            strFullAddress += " ";
            strFullAddress += strZipCode;
            // strFullAddress = "6785 Barker Rd. Bickman, MS 68321"

            // Concatenate a string and a number.
            Decimal decPrice = 199.00m;
            String strPrice = "Price: " + decPrice;
            // strPrice = "Price: 199.00"

        }

        protected void EscapeSequences()
        {

            // Use the new line escape sequence (\n).
            String strAddress = "6785 Barker Rd.";
            String strCity = "Bickman";
            String strState = "MS";
            String strZipCode = "68321";
            String strFullAddress = "";
            strFullAddress = strAddress + "\n" + strCity + ", " + strState + " " + strZipCode;
            // strFullAddress = "6785 Barker Rd.
            //                   Bickman, MS 68321"

            // Use the tab escape sequence (\t).
            String strLastName1 = "Jones";
            String strFirstName1 = "Joe";
            String strLastName2 = "Smith";
            String strFirstName2 = "Sally";
            String strNameList = strLastName1 + "\t" + strFirstName1 + "\n" + strLastName2 + "\t" + strFirstName2;
            // strNameList = "Jones	Joe
            //                Smith  Sally"

            // Use the backslash escape sequence (\\).
            String strFilePath = "c:\\myfolder\\myfile.txt";
            // strFilePath = "c:\myfolder\myfile.txt"

            // Use the quote escape sequence (\").
            String strMessage = "Please click \"Submit\" to complete your order.";
            // strMessage = "Please click "Submit" to complete your order."

        }

        protected void VerbatimLiterals()
        {

            // Use a verbatim literal.
            String strFilePath = @"c:\myfolder\myfile.txt";
            // strFilePath = "c:\myfolder\myfile.txt"

            // Use a verbatim literal.
            String strMessage = @"Please click ""Submit"" to complete your order.";
            // strMessage = "Please click "Submit" to complete your order."

        }

        protected void StringClassProperties()
        {

            // Get the number of characters in the string.
            String strAddress = "123 Main Street";
            Int32 i32LengthOfString = strAddress.Length;
            // i32LengthOfString = 15

        }

        protected void StringClassMethods()
        {

            // Concatenate three strings.
            String strLastName = "Billingsley";
            String strFirstName = "Beth";
            String strMiddleInitial = "B";
            String strFullName = String.Concat(strFirstName, " ", strMiddleInitial, " ", strLastName);
            // strFullName = "Beth B Billingsley"

            // Check to see if the word "unhappy" exists in the string.
            String strNotes = "Mr. Richards was unhappy with his order.";
            Boolean booUnhappy = strNotes.Contains("unhappy");
            // booUnhappy = true

            // Check to see if the string ends with ".jpg".
            String strImage = "NMSFA7S.jpg";
            Boolean booCorrectFileType = strImage.EndsWith(".jpg");
            // booCorrectFileType = true

            // Get the position of "gmail" in the string.
            String strEmailAddress = "mmyers@gmail.com";
            Int32 i32DomainLocation = strEmailAddress.IndexOf("gmail");
            // i32DomainLocation = 7

            // Insert dashes into the string.
            String strPhoneOld = "1234567890";
            String strPhoneNew = "";
            strPhoneNew = strPhoneOld.Insert(3, "-");
            strPhoneNew = strPhoneNew.Insert(7, "-");
            // strPhoneNew = "123-456-7890"

            // Determine whether or not the string is null.
            String strAddress1 = null;
            String strAddress2 = "";
            String strAddress3 = "123 Main Street";
            Boolean booIsNull;
            booIsNull = String.IsNullOrEmpty(strAddress1);
            // booIsNull = true
            booIsNull = String.IsNullOrEmpty(strAddress2);
            // booIsNull = true
            booIsNull = String.IsNullOrEmpty(strAddress3);
            // booIsNull = false

            // Find the position of the last "." in the string.
            strEmailAddress = "Cecil.C.Cook@yahoo.com";
            Int32 i32LastPeriod = strEmailAddress.LastIndexOf(".");
            // i32LastPeriod = 18

            // Right-align the characters in a 15 character string by
            // padding them with spaces on the left.
            String strLastNameOld = "Fredericks";
            String strLastNameNew = strLastNameOld.PadLeft(15);
            // strLastNameNew = "     Fredericks"

            // Left-align the characters in a 15 character string by
            // padding them with spaces on the right.
            strLastNameOld = "Fredericks";
            strLastNameNew = strLastNameOld.PadRight(15);
            // strLastNameNew = "Fredericks     "

            // Remove all the characters in the string beginning
            // with the 10th character.
            String strZipCodeOld = "12345-0000";
            String strZipCodeNew = strZipCodeOld.Remove(5);
            // strZipCodeNew = "12345"

            // Replace all of the "-" in the string with "/".
            String strDateOld = "20xx-07-10";
            String strDateNew = strDateOld.Replace("-", "/");
            // strDateNew = "20xx/07/10"

            // Split the string up by " ", ",", and "." and
            // place each word in an array.
            Char[] chaSeparator = new Char[] {' ', ',', '.'};
            String[] strMessageArray = new String[5];
            String strMessage = "For today's special, see below.";
            strMessageArray = strMessage.Split(chaSeparator, StringSplitOptions.RemoveEmptyEntries);
            // strMessageArray[0] = "For"
            // strMessageArray[1] = "today's"
            // strMessageArray[2] = "special"
            // strMessageArray[3] = "see"
            // strMessageArray[4] = "below"

            // Check to see if the string begins with "Nike".
            String strProduct = "Nike Flare Women's Shoe";
            Boolean booNike = strProduct.StartsWith("Nike");
            // booNike = true

            // Extract characters from the string beginning at position
            // 5 for a length of 2.
            String strDate = "20xx-07-10";
            String strMonth = strDate.Substring(5, 2);
            // strMonth = "07"

            // Force all of the characters in the string to lower case.
            String strPasswordOld = "ABC123";
            String strPasswordNew = strPasswordOld.ToLower();
            // strPasswordNew = "abc123"

            // Format the number as a string.
            Decimal decPrice = 199.00m;
            String strPrice = decPrice.ToString();
            // strPrice = "199.00"

            // Format the number as currency with the specified
            // number of decimal places.
            decPrice = 199.00m;
            strPrice = decPrice.ToString("c2");
            // strPrice = "$199.00"

            // Format the number with the specified number of decimal places.
            decPrice = 10.99m;
            strPrice = decPrice.ToString("f4");
            // strPrice = "10.9900"

            // Format the number with thousands separators with the specified
            // number of decimal places.
            decPrice = 1099m;
            strPrice = decPrice.ToString("n2");
            // strPrice = "1,099.00"

            // Format the number as a percentage with the specified
            // number of decimal places. Note: decNumberInStock and
            // decReorderLevel cannot be defined as integers or
            // interger division will take place, which will not
            // yield the correct result.
            Decimal decNumberInStock = 9m;
            Decimal decReorderLevel = 2m;
            Decimal decSafetyLevel = 1 - (decReorderLevel / decNumberInStock);
            String strSafetyLevel = decSafetyLevel.ToString("p0");
            // strSafetyLevel = "78%"

            // Force all of the characters in the string to upper case.
            strPasswordOld = "abc123";
            strPasswordNew = strPasswordOld.ToUpper();
            // strPasswordNew = "ABC123"

            // Remove from the string all leading and trailing blanks.
            strLastNameOld = "   Everest   ";
            strLastNameNew = strLastNameOld.Trim();
            // strLastNameNew = "Everest"

            // Remove from the string all leading and trailing characters
            // that are in the array of characters to be removed.
            Char[] chaCharactersToRemove = new Char[] {'*', '#'};
            strLastNameOld = "*#*Everest#*#";
            strLastNameNew = strLastNameOld.Trim(chaCharactersToRemove);
            // strLastNameNew = "Everest"

        }

    }

}