﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class Arithmetic : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            ArithmeticOperators();
            OrderOfPrecedenceAndAssociativity();
            Parentheses();
            MathClassMethods();

        }

        protected void ArithmeticOperators()
        {

            // Declare the variables.
            Int16 i16Number1 = 0;
            Double dblNumber1 = 0;
            Double dblNumber2 = 0;
            Double dblResult;

            // Add the numbers.
            dblNumber1 = 40;
            dblNumber2 = 8;
            dblResult = dblNumber1 + dblNumber2;
            // dblResult = 48

            // Subtract the numbers.
            dblNumber1 = 70;
            dblNumber2 = 10;
            dblResult = dblNumber1 - dblNumber2;
            // dblResult = 60

            // Multiply the numbers.
            dblNumber1 = 3;
            dblNumber2 = 2;
            dblResult = dblNumber1 * dblNumber2;
            // dblResult = 6

            // Divide the numbers.
            dblNumber1 = 7;
            dblNumber2 = 4;
            dblResult = dblNumber1 / dblNumber2;
            // dblResult = 1.75

            // Divide the first number by the second number giving the remainder.
            dblNumber1 = 12;
            dblNumber2 = 7;
            dblResult = dblNumber1 % dblNumber2;
            // dblResult = 5

            // Increment the number after the assignment.
            i16Number1 = 3;
            dblResult = i16Number1++;
            // dblResult = 3, i16Number1 = 4

            // Decrement the number after the assignment.
            i16Number1 = 7;
            dblResult = i16Number1--;
            // dblResult = 7, i16Number1 = 6

            // Increment the number before the assignment.
            i16Number1 = 12;
            dblResult = ++i16Number1;
            // dblResult = 13, i16Number1 = 13

            // Decrement the number before the assignment.
            i16Number1 = 40;
            dblResult = --i16Number1;
            // dblResult = 39, i16Number1 = 39

        }

        protected void OrderOfPrecedenceAndAssociativity()
        {

            // Declare the variables.
            Byte bytValue;
            Double dblNumber1 = 2;
            Double dblNumber2 = 3;
            Double dblNumber3 = 4;
            Double dblResult;

            // This is an example of order of precedence.
            bytValue = 1;
            dblResult = dblNumber1 * dblNumber2 * ++bytValue;
            // dblResult = 12

            // This is the equivalent.
            bytValue = 1;
            dblResult = dblNumber1 * dblNumber2 * (++bytValue);
            // dblResult = 12

            // This is an example of order of precedence.
            dblResult = dblNumber1 + dblNumber2 * dblNumber3;
            // dblResult = 14

            // This is the equivalent.
            dblResult = dblNumber1 + (dblNumber2 * dblNumber3);
            // dblResult = 14

            // This is an example of left associativity.
            dblResult = dblNumber1 * dblNumber2 % dblNumber3;
            // dblResult = 2

            // This is the equivalent.
            dblResult = (dblNumber1 * dblNumber2) % dblNumber3;
            // dblResult = 2

            // This is an example of right associativity.
            dblResult = dblNumber1 = dblNumber2 = dblNumber3;
            // dblResult = 4

            // This is the equivalent.
            dblResult = (dblNumber1 = (dblNumber2 = dblNumber3));
            // dblResult = 4

        }

        protected void Parentheses()
        {

            // Declare the variables.
            Double dblNumber1 = 2;
            Double dblNumber2 = 3;
            Double dblNumber3 = 4;
            Double dblResult;

            // This is an example of order of precedence.
            dblResult = dblNumber1 + dblNumber2 * dblNumber3;
            // dblResult = 14

            // This is the equivalent.
            dblResult = dblNumber1 + (dblNumber2 * dblNumber3);
            // dblResult = 14

            // This is overriding the order of precedence using parentheses.
            dblResult = (dblNumber1 + dblNumber2) * dblNumber3;
            // dblResult = 20

            // This is an example of left associativity.
            dblResult = dblNumber1 * dblNumber2 % dblNumber3;
            // dblResult = 2

            // This is the equivalent.
            dblResult = (dblNumber1 * dblNumber2) % dblNumber3;
            // dblResult = 2

            // This is overriding the left associativity using parentheses.
            dblResult = dblNumber1 * (dblNumber2 % dblNumber3);
            // dblResult = 6

        }

        protected void MathClassMethods()
        {

            // Declare the variables.
            Double dblNumber1 = 0;
            Double dblNumber2 = 0;
            Double dblResult;

            // Compute the absolute value.
            dblNumber1 = -3.21;
            dblResult = Math.Abs(dblNumber1);
            // dblResult = 3.21

            // Compute the ceiling.
            dblNumber1 = 3.21;
            dblResult = Math.Ceiling(dblNumber1);
            // dblResult = 4

            // Compute the ceiling.
            dblNumber1 = -3.21;
            dblResult = Math.Ceiling(dblNumber1);
            // dblResult = -3

            // Compute the ceiling.
            dblNumber1 = 0.21;
            dblResult = Math.Ceiling(dblNumber1);
            // dblResult = 1

            // Compute the ceiling.
            dblNumber1 = -0.21;
            dblResult = Math.Ceiling(dblNumber1);
            // dblResult = 0

            // Compute the floor.
            dblNumber1 = 3.21;
            dblResult = Math.Floor(dblNumber1);
            // dblResult = 3

            // Compute the floor.
            dblNumber1 = -3.21;
            dblResult = Math.Floor(dblNumber1);
            // dblResult = -4

            // Compute the floor.
            dblNumber1 = 0.21;
            dblResult = Math.Floor(dblNumber1);
            // dblResult = 0

            // Compute the floor.
            dblNumber1 = -0.21;
            dblResult = Math.Floor(dblNumber1);
            // dblResult = -1

            // Get the larger of the two numbers.
            dblNumber1 = 3.5;
            dblNumber2 = 7.5;
            dblResult = Math.Max(dblNumber1, dblNumber2);
            // dblResult = 7.5

            // Get the smaller of the two numbers.
            dblNumber1 = 3.5;
            dblNumber2 = 7.5;
            dblResult = Math.Min(dblNumber1, dblNumber2);
            // dblResult = 3.5

            // Raise the number to the 3rd power.
            dblNumber1 = 3;
            dblResult = Math.Pow(dblNumber1, 3);
            // dblResult = 27

            // Round the number up or down to the nearest even value.
            // This is banker's rounding, which is the default.
            dblNumber1 = 1.5;
            dblResult = Math.Round(dblNumber1, 0, MidpointRounding.ToEven);
            // dblResult = 2 (Rounded up.)

            // Round the number up or down to the nearest even value.
            // This is banker's rounding, which is the default.
            dblNumber1 = 2.5;
            dblResult = Math.Round(dblNumber1, 0, MidpointRounding.ToEven);
            // dblResult = 2 (Rounded down.)

            // Round the number up or down to the nearest value.
            // This is standard rounding, which is not the default.
            dblNumber1 = 1.5;
            dblResult = Math.Round(dblNumber1, 0, MidpointRounding.AwayFromZero);
            // dblResult = 2 (Rounded up.)

            // Round the number up or down to the nearest value.
            // This is standard rounding, which is not the default.
            dblNumber1 = 2.5;
            dblResult = Math.Round(dblNumber1, 0, MidpointRounding.AwayFromZero);
            // dblResult = 3 (Rounded up.)

            // Get the sign of the number.
            dblNumber1 = 12;
            dblResult = Math.Sign(dblNumber1);
            // dblResult = 1

            // Get the sign of the number.
            dblNumber1 = -12;
            dblResult = Math.Sign(dblNumber1);
            // dblResult = -1

            // Compute the square root of the number.
            dblNumber1 = 16;
            dblResult = Math.Sqrt(dblNumber1);
            // dblResult = 4

            // Truncate the number.
            dblNumber1 = 3.712;
            dblResult = Math.Truncate(dblNumber1);
            // dblResult = 3

        }

    }

}
