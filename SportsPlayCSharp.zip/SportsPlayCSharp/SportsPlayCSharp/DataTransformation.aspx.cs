﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlayCSharp
{
    public partial class DataTransformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            ImplicitConversions();
            ExplicitConversions();
            ConvertClass();
            ConvertClassFromTextBox();

        }

        protected void ImplicitConversions()
        {

            // Implicitly convert an 8-bit unsigned integer to a 16-bit unsigned
            // integer.
            Byte bytNumber = 100;
            UInt16 u16Number = 0;
            u16Number = bytNumber;
            // u16Number = 100

            // Implicitly convert a 32-bit signed integer to a 64-bit signed integer.
            Int32 i32Number = -123;
            Int64 i64Number = 0;
            i64Number = i32Number;
            // i64Number = -123

            // Implicitly convert an 8-bit signed integer to a single-precision
            // (32-bit) floating-point number.
            SByte sbyNumber = -12;
            Single sinNumber = 0f;
            sinNumber = sbyNumber;
            // sinNumber = -12

            // Implicitly convert a single-precision (32-bit) floating-point number to
            // a double-precision (64-bit) floating-point number.
            Single sinNumberSmaller = 12345.56789f;
            Double dblNumberLarger = 0;
            dblNumberLarger = sinNumberSmaller;
            // dblNumberLarger = 12345.568359375

            // Implicitly convert the variable types in the expression before
            // evaluating the expression.
            Double dblNumber1 = 3;
            Int16 i16Number2 = 7;
            Int16 i16Number3 = 12;
            Double dblAverage = 0;
            dblAverage = (dblNumber1 + i16Number2 + i16Number3)/3;
            // dblAverage = 7.33...

        }

        protected void ExplicitConversions()
        {

            // Explicitly convert (i.e., cast) a 16-bit unsigned integer to an 8-bit
            // unsigned integer.
            UInt16 u16Number = 100;
            Byte bytNumber = 0;
            bytNumber = (Byte)u16Number;
            // bytNumber = 100

            // Explicitly convert (i.e., cast) a 64-bit signed integer to a 32-bit
            // signed integer.
            Int64 i64Number = -123;
            Int32 i32Number = 0;
            i32Number = (Int32)i64Number;
            // i32Number = -123

            // Explicitly convert (i.e., cast) a decimal (128-bit) value to a
            // double-precision (64-bit) floating-point number.
            Decimal decNumber = 123.45m;
            Double dblNumber = 0;
            dblNumber = (Double)decNumber;
            // dblNumber = 123.45

            // Explicitly convert (i.e., cast) a single-precision (32-bit)
            // floating-point number to an 8-bit signed integer.
            Single sinNumber = -12.50f;
            SByte sbyNumber = 0;
            sbyNumber = (SByte)sinNumber;
            // sbyNumber = -12

            // Explicitly convert (i.e., cast) a 16-bit signed integer to an 8-bit
            // unsigned integer.
            Int16 i16NumberSigned = -100;
            Byte bytNumberUnsigned = 0;
            bytNumberUnsigned = (Byte)i16NumberSigned;
            // bytNumber = 156

            // Explicitly convert (i.e., cast) a 16-bit unsigned integer to an 8-bit
            // unsigned integer that is too large to fit.
            UInt16 u16NumberTooLarge = 65535;
            Byte bytNumberTooSmall = 0;
            bytNumberTooSmall = (Byte)u16NumberTooLarge;
            // bytNumberTooSmall = 255

        }

        protected void ConvertClass()
        {

            // Convert the 8-bit unsigned integer to its equivalent Unicode
            // (16-bit) character.
            Byte bytNumber = 65;
            Char[] chaUnicodeCharacter = new Char[1];
            chaUnicodeCharacter[0] = Convert.ToChar(bytNumber);
            // chaUnicodeCharacter[0] = "A"

            // Convert the DateTime structure to its equivalent immutable,
            // fixed-length string of Unicode characters.
            DateTime datDate = DateTime.Today;
            String strDate = "";
            strDate = Convert.ToString(datDate);
            // strDate = "7/21/2017 12:00:00 AM"

            // Convert the 8-bit signed integer to its equivalent 16-bit
            // unsigned integer.
            SByte sbyReorderLevel = 33;
            UInt16 u16ReorderLevel = 0;
            u16ReorderLevel = Convert.ToUInt16(sbyReorderLevel);
            // u16ReorderLevel = 33

            // Convert the single-precision (32-bit) floating-point number to its
            // equivalent double-precision (64-bit) floating-point number.
            Single sinAmount = 7.1234f;
            Double dblAmount = 0;
            dblAmount = Convert.ToDouble(sinAmount);
            // dblAmount = 7.1234002113342285

            // Convert the 32-bit signed integer to its equivalent Boolean
            // value (true or false).
            Int32 i32Flag = 1;
            Boolean booFlag = false;
            booFlag = Convert.ToBoolean(i32Flag);
            // booFlag = true

            // Convert the immutable, fixed-length string of Unicode characters
            // to its equivalent 8-bit unsigned integer.
            String strAge = "3";
            Byte bytAge = 0;
            bytAge = Convert.ToByte(strAge);
            // bytAge = 3

            // Convert the immutable, fixed-length string of Unicode characters
            // to its equivalent DateTime structure.
            String strDateTime = "7/20/2017";
            DateTime datDateTime = new DateTime();
            datDateTime = Convert.ToDateTime(strDateTime);
            // datDateTime = {7/20/2017 12:00:00 AM}

            // Convert the 16-bit unsigned integer to its equivalent 8-bit
            // signed integer.
            UInt16 u16NumberOnOrder = 100;
            SByte sbyNumberOnOrder = 0;
            sbyNumberOnOrder = Convert.ToSByte(u16NumberOnOrder);
            // sbyNumberOnOrder = 100

            // Convert the double-precision (64-bit) floating-point number to
            // its equivalent single-precision (32-bit) floating-point number.
            Double dblRefund = -123.45;
            Single sinRefund = 0;
            sinRefund = Convert.ToSingle(dblRefund);
            // sinRefund = -123.45

            // Convert the decimal (128-bit) value to its equivalent 16-bit
            // signed integer.
            Decimal decNumberInStock = 122.5m;
            Int16 i16NumberInStock = 0;
            i16NumberInStock = Convert.ToInt16(decNumberInStock);
            // i16NumberInStock = 122

        }

        protected void ConvertClassFromTextBox()
        {

            // Convert the text box value to its equivalent
            // decimal (128-bit) value.
            txtInput.Text = "12.34"; // Entered by the end user.
            Decimal decPrice = 0;
            decPrice = Convert.ToDecimal(txtInput.Text);
            // decPrice = 12.34

            // Convert the text box value to its equivalent
            // DateTime structure.
            txtInput.Text = "7/20/2017"; // Entered by the end user.
            DateTime datDateTime = new DateTime();
            datDateTime = Convert.ToDateTime(txtInput.Text);
            // datDateTime = {7/20/2017 12:00:00 AM}

            // Convert the text box value to its equivalent
            // Boolean value (true or false).
            txtInput.Text = "1"; // Entered by the end user.
            Boolean booFlag = false;
            Byte bytFlag = Convert.ToByte(txtInput.Text);
            booFlag = Convert.ToBoolean(bytFlag);
            // booFlag = true

            // Convert the text box value to its equivalent
            // Unicode (16-bit) character.
            txtInput.Text = "65"; // Entered by the end user.
            Char[] chaUnicodeCharacter = new Char[1];
            UInt16 u16Number = Convert.ToUInt16(txtInput.Text);
            chaUnicodeCharacter[0] = Convert.ToChar(u16Number);
            // chaUnicodeCharacter[0] = "A"

        }

    }

}