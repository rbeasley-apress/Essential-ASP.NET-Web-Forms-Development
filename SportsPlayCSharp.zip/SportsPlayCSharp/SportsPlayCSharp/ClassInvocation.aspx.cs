﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SportsPlayCSharp.Classes;

namespace SportsPlayCSharp
{
    public partial class ClassInvocation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //// Declare the variables.
            //String strLastName = "Billingsley";
            //String strFirstName = "Beth";
            //String strMiddleInitial = "B";
            //String strAddress = "6785 Barker Rd.";
            //String strCity = "Bickman";
            //String strState = "MS";
            //String strZipCode = "68321";
            //String strPhone = "765-987-1432";
            //String strEmailAddress = "";
            //String strPassword = "abc";

            //// Create an instance of the non-static Employee class.
            //Employee empEmployee = new Employee();

            //// Generate an email address for the employee.
            //strEmailAddress = empEmployee.GenerateEmailAddress(strLastName, strFirstName);

            //// Set the properties of the Employee object.
            //empEmployee.LastName = strLastName;
            //empEmployee.FirstName = strFirstName;
            //empEmployee.MiddleInitial = strMiddleInitial;
            //empEmployee.Address = strAddress;
            //empEmployee.City = strCity;
            //empEmployee.State = strState;
            //empEmployee.ZipCode = strZipCode;
            //empEmployee.Phone = strPhone;
            //empEmployee.EmailAddress = strEmailAddress;
            //empEmployee.Password = strPassword;

            //// Get the properties of the Employee object.
            //String strLastName2 = empEmployee.LastName;
            //// strLastName2 = "Billingsley"
            //String strFirstName2 = empEmployee.FirstName;
            //// strFirstName2 = "Beth"
            //String strMiddleInitial2 = empEmployee.MiddleInitial;
            //// strMiddleInitial2 = "B"
            //String strAddress2 = empEmployee.Address;
            //// strAddress2 = "6785 Barker Rd."
            //String strCity2 = empEmployee.City;
            //// strCity2 = "Bickman"
            //String strState2 = empEmployee.State;
            //// strState2 = "MS"
            //String strZipCode2 = empEmployee.ZipCode;
            //// strZipCode2 = "68321"
            //String strPhone2 = empEmployee.Phone;
            //// strPhone2 = "765-987-1432"
            //String strEmailAddress2 = empEmployee.EmailAddress;
            //// strEmailAddress2 = "bbillingsley@sportsplay.com"
            //String strPassword2 = empEmployee.Password;
            //// strPassword2 = "abc"

            // Generate a password using the static Password class.
            String strLastName = "Jones";
            String strFirstName = "Jerry";
            Byte bytLength = 7;
            String strPassword = Password.Generate(strLastName, strFirstName, bytLength);
            // strPassword = "jj14$%5"

        }

    }

}