﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class SqlDataSourceClassSessionParameter : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // Set the CategoryID session variable. Don't show this being
            // done in the book as it is just used to set up the example.
            Session["intCategoryID"] = 2;

        }

    }

}