﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class RadioButtonClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSelectShipper_Click(object sender, EventArgs e)
        {

            String strShipper = "You have selected ";
            if(radUSPS.Checked)
            {
                strShipper = strShipper + "USPS ";
            }
            else if(radUPS.Checked)
            {
                strShipper = strShipper + "UPS ";
            }
            else
            {
                strShipper = strShipper + "FedEx ";
            }
            strShipper = strShipper + "as your shipper.";
            lblShipper.Text = strShipper;

        }

    }

}