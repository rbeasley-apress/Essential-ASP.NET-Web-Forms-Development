﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Net.Mail;

namespace SportsPlay
{
    public partial class MailMessageClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
        }

        protected void btnSendPassword_Click(object sender, EventArgs e)
        {

            // Develop the SQL call.
            String strSQL = "";
            strSQL = "SELECT FirstName + ' ' + MiddleInitial + ' ' + LastName AS FullName, Password ";
            strSQL += " FROM Employee ";
            strSQL += "WHERE EmailAddress = @EmailAddress ";
            // Define the network connection to the SQL Server database.
            SqlConnection objSqlConnection = new SqlConnection(WebConfigurationManager.ConnectionStrings["SportsPlay"].ConnectionString);
            // Set up the SQL command object.
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandType = CommandType.Text;
            objSqlCommand.CommandText = strSQL;
            // Define the input parameters.
            objSqlCommand.Parameters.AddWithValue("@EmailAddress", txtEmailAddress.Text);
            // Open the connection and execute the data reader.
            objSqlConnection.Open();
            SqlDataReader objSqlDataReader = objSqlCommand.ExecuteReader();
            // Attempt to retrieve the row from the table.
            if (objSqlDataReader.Read())
            {
                // Save the full name and password.
                String strFullName = objSqlDataReader["FullName"].ToString();
                String strPassword = objSqlDataReader["Password"].ToString();
                // Close the data reader and the connection.
                objSqlDataReader.Close();
                objSqlConnection.Close();
                // Build the email message.
                MailMessage objMailMessage = new MailMessage();
                objMailMessage.From = new MailAddress("noreply@sportsplay.com");
                objMailMessage.To.Add(new MailAddress(txtEmailAddress.Text));
                objMailMessage.Subject = "Password Retrieval";
                objMailMessage.Body = "Dear " + strFullName + "," + "<br /><br />Please retain the following password as you will need it to login to the system.<br /><br />Password: <i>" + strPassword + "</i><br /><br />Thank you.";
                objMailMessage.IsBodyHtml = true;
                // Send the email message.
                SmtpClient objSmtpClient = new SmtpClient();
                objSmtpClient.Send(objMailMessage);
                objSmtpClient.Dispose();
                // Set the message.
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Your email address was found, and your password was sent. Please check your email.";
            }
            else
            {
                // Close the data reader and the connection.
                objSqlDataReader.Close();
                objSqlConnection.Close();
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Your email address was NOT found. Please check your email address for accuracy and try again.";
            }

        }

    }
}