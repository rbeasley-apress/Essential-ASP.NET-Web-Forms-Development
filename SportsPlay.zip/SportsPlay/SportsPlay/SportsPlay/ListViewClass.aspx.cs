﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

namespace SportsPlay
{
    public partial class ListViewClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void livProduct_ItemInserted(object sender, ListViewInsertedEventArgs e)
        {

            // Make sure the database call was successful.
            if (e.Exception == null)
            {
                if (e.AffectedRows == 1)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Product successfully added.";
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully added. Please report this message to....: The number of products added was not equal to 1.";
                    e.KeepInInsertMode = true;
                }
            }
            else
            {
                // An exception has occurred.
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Product NOT successfully added. Please report this message to....: " + e.Exception.Message;
                e.KeepInInsertMode = true;
                e.ExceptionHandled = true;
            }

        }

        protected void livProduct_ItemUpdated(object sender, ListViewUpdatedEventArgs e)
        {

            // Make sure the database call was successful.
            if (e.Exception == null)
            {
                if (e.AffectedRows == 1)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Product successfully modified.";
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully modified. Please report this message to....: The number of products modified was not equal to 1.";
                    e.KeepInEditMode = true;
                }
            }
            else
            {
                // An exception has occurred.
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Product NOT successfully modified. Please report this message to....: " + e.Exception.Message;
                e.KeepInEditMode = true;
                e.ExceptionHandled = true;
            }

        }

        protected void livProduct_ItemDeleted(object sender, ListViewDeletedEventArgs e)
        {

            // Make sure the database call was successful.
            if (e.Exception == null)
            {
                if (e.AffectedRows == 1)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Product successfully deleted.";
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully deleted. Please report this message to....: The number of products deleted was not equal to 1.";
                }
            }
            else
            {
                if (((SqlException)e.Exception).Number.Equals(547))
                {
                    // A foreign key constraint violation has occurred.
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully deleted because it is associated with at least one order line. To delete this product, you must first delete all of its associated order lines.";
                    e.ExceptionHandled = true;
                }
                else
                {
                    // Some other exception has occurred.
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully deleted. Please report this message to....: " + e.Exception.Message;
                    e.ExceptionHandled = true;
                }
            }

        }

        protected void livProduct_ItemDeleting(object sender, ListViewDeleteEventArgs e)
        {

            // Get the filename of the image to be deleted.
            ListViewItem lviListViewItem = livProduct.Items[e.ItemIndex];
            TextBox txtImage = (TextBox)lviListViewItem.FindControl("txtImage");
            String strImage = txtImage.Text;
            // Delete the associated file from the hard drive.
            String strFilePath = Request.PhysicalApplicationPath + "Images\\" + strImage;
            if (File.Exists(strFilePath))
            {
                File.Delete(strFilePath);
            }

        }

        protected void livProduct_ItemCanceling(object sender, ListViewCancelEventArgs e)
        {

            // Cancel the insert or update operation.
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "Operation cancelled. No data was affected.";

        }

    }

}