﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class DropDownListClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlSupplier_SelectedIndexChanged(object sender, EventArgs e)
        {

            lblSupplierIndex.Text = ddlSupplier.SelectedIndex.ToString();
            lblSupplierValue.Text = ddlSupplier.SelectedItem.Value;
            lblSupplierText.Text = ddlSupplier.SelectedItem.Text;

        }

    }

}