﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

namespace SportsPlay
{
    public partial class FormViewClass : System.Web.UI.Page
    {

        // Define the variable used to store the newly inserted primary key.
        Int32 i32NewlyInsertedPrimaryKey;

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void sdsFormViewProduct_Inserted(object sender, SqlDataSourceStatusEventArgs e)
        {

            // Get the primary key of the newly inserted row. This is used
            // in the FormViewItemInserted method to position the associated
            // DropDownList and FormView on the newly inserted row.
            if (e.Exception == null)
            {
                i32NewlyInsertedPrimaryKey = (Int32)e.Command.Parameters["@ProductID"].Value;
            }

        }

        protected void fovProduct_ItemInserted(object sender, FormViewInsertedEventArgs e)
        {

            // Make sure the database call was successful.
            if (e.Exception == null)
            {
                if (e.AffectedRows == 1)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Product successfully added.";
                    // Refresh the page data.
                    ddlProduct.DataBind();
                    ddlProduct.SelectedValue = i32NewlyInsertedPrimaryKey.ToString();
                    fovProduct.DataBind();
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully added. Please report this message to....: The number of products added was not equal to 1.";
                    e.KeepInInsertMode = true;
                }
            }
            else
            {
                // An exception has occurred.
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Product NOT successfully added. Please report the following message to....: " + e.Exception.Message;
                e.KeepInInsertMode = true;
                e.ExceptionHandled = true;
            }

        }

        protected void fovProduct_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
        {

            // Make sure the database call was successful.
            if (e.Exception == null)
            {
                if (e.AffectedRows == 1)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Product successfully modified.";
                    // Refresh the page data.
                    String strSelectedValue;
                    strSelectedValue = ddlProduct.SelectedValue;
                    ddlProduct.DataBind();
                    ddlProduct.SelectedValue = strSelectedValue.ToString();
                    fovProduct.DataBind();
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully modified. Please report this message to....: The number of products modified was not equal to 1.";
                    e.KeepInEditMode = true;
                }
            }
            else
            {
                // An exception has occurred.
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Product NOT successfully modified. Please report the following message to....: " + e.Exception.Message;
                e.KeepInEditMode = true;
                e.ExceptionHandled = true;
            }

        }

        protected void fovProduct_ItemDeleted(object sender, FormViewDeletedEventArgs e)
        {

            // Make sure the database call was successful.
            if (e.Exception == null)
                {
                if (e.AffectedRows == 1)
                    {
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Product successfully deleted.";
                    // Refresh the page data.
                    ddlProduct.DataBind();
                    fovProduct.DataBind();
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully deleted. Please report this message to....: The number of products deleted was not equal to 1.";
                }
            }
            else
            {
                if (((SqlException)e.Exception).Number.Equals(547))
                {
                    // A foreign key constraint violation has occurred.
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully deleted because it is associated with at least one order line. To delete this product, you must first delete all of its associated order lines.";
                    e.ExceptionHandled = true;
                }
                else
                {
                    // Some other exception has occurred.
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Product NOT successfully deleted. Please report the following message to....: " + e.Exception.Message;
                    e.ExceptionHandled = true;
                }
            }

        }

        protected void fovProduct_ItemDeleting(object sender, FormViewDeleteEventArgs e)
        {

            // Get the filename of the image to be deleted.
            TextBox txtImage = (TextBox)fovProduct.FindControl("txtImage");
            String strImage = txtImage.Text;
            // Delete the associated file from the hard drive.
            String strFilePath = Request.PhysicalApplicationPath + "Images\\" + strImage;
            if (File.Exists(strFilePath))
            {
                File.Delete(strFilePath);
            }

        }

        protected void fovProduct_ModeChanging(object sender, FormViewModeEventArgs e)
        {
            
            // Cancel the insert or update operation.
            if (e.CancelingEdit)
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Operation cancelled. No data was affected.";
            }

        }

    }

}