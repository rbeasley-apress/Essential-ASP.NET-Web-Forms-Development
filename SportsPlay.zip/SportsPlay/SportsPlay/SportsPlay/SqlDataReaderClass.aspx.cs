﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace SportsPlay
{
    public partial class SqlDataReaderClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {

            // Develop the SQL call.
            String strSQL = "";
            strSQL = "SELECT LastName, FirstName, MiddleInitial, Phone ";
            strSQL += " FROM Customer ";
            strSQL += "ORDER BY LastName, FirstName, MiddleInitial ";
            // Define the network connection to the SQL Server database.
            SqlConnection objSqlConnection = new SqlConnection(WebConfigurationManager.ConnectionStrings["SportsPlay"].ConnectionString);
            // Create the SQL command object.
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandType = CommandType.Text;
            objSqlCommand.CommandText = strSQL;
            // Open the connection and execute the data reader.
            objSqlConnection.Open();
            SqlDataReader objSqlDataReader = objSqlCommand.ExecuteReader();
            // Retrieve each row and display in the text box.
            while (objSqlDataReader.Read())
            {
                txtCustomers.Text = txtCustomers.Text + objSqlDataReader["LastName"].ToString() + ", " + objSqlDataReader["FirstName"].ToString() + " " + objSqlDataReader["MiddleInitial"].ToString() + " (" + objSqlDataReader["Phone"].ToString() + ")\r";
            }
            // Close the data reader and the connection.
            objSqlDataReader.Close();
            objSqlConnection.Close();

        }

    }

}