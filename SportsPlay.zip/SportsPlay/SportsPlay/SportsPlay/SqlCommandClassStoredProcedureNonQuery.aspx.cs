﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace SportsPlay
{
    public partial class SqlCommandClassStoredProcedureNonQuery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            // Define the network connection to the SQL Server database.
            SqlConnection objSqlConnection = new SqlConnection(WebConfigurationManager.ConnectionStrings["SportsPlay"].ConnectionString);
            // Set up the SQL command object.
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandType = CommandType.StoredProcedure;
            objSqlCommand.CommandText = "ProductModify";
            // Define the input parameters.
            objSqlCommand.Parameters.AddWithValue("@ProductID", txtProductID.Text);
            objSqlCommand.Parameters.AddWithValue("@CategoryID", ddlCategory.SelectedValue);
            objSqlCommand.Parameters.AddWithValue("@SupplierID", ddlSupplier.SelectedValue);
            objSqlCommand.Parameters.AddWithValue("@Product", txtProduct.Text);
            objSqlCommand.Parameters.AddWithValue("@Description", txtDescription.Text);
            objSqlCommand.Parameters.AddWithValue("@Image", txtImage.Text);
            objSqlCommand.Parameters.AddWithValue("@Price", txtPrice.Text);
            objSqlCommand.Parameters.AddWithValue("@NumberInStock", txtNumberInStock.Text);
            objSqlCommand.Parameters.AddWithValue("@NumberOnOrder", txtNumberOnOrder.Text);
            objSqlCommand.Parameters.AddWithValue("@ReorderLevel", txtReorderLevel.Text);
            // Define the output parameters.
            objSqlCommand.Parameters.Add("@RowCount", SqlDbType.Int).Direction = ParameterDirection.Output;
            // Open the connection and execute the non-query.
            objSqlConnection.Open();
            objSqlCommand.ExecuteNonQuery();
            if ((Int32)objSqlCommand.Parameters["@RowCount"].Value == 1)
            {
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Product successfully modified.";
            }
            else
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Product NOT successfully modified. Please report this message to....:";
            }
            // Close the connection.
            objSqlConnection.Close();

        }

    }

}