﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class ImageMapClass2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void imgShipperMap_Click(object sender, ImageMapEventArgs e)
        {

            String strShipper = "You have selected ";
            switch (e.PostBackValue)
            {
                case "USPS":
                    strShipper = strShipper + "USPS ";
                    break;
                case "UPS":
                    strShipper = strShipper + "UPS ";
                    break;
                case "FedEx":
                    strShipper = strShipper + "FedEx ";
                    break;
            }
            strShipper = strShipper + "as your shipper.";
            lblShipper.Text = strShipper;

        }

    }

}