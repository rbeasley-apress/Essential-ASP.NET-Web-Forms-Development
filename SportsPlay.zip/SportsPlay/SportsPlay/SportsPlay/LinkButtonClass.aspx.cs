﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class LinkButtonClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnModify_Click(object sender, EventArgs e)
        {

            // The database call to update the email address would go here.
            // If successful, the following message would be displayed.
            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Text = "The email address was successfully modified.";

        }

    }

}