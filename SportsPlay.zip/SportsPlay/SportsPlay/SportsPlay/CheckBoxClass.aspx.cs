﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class CheckBoxClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSetFilter_Click(object sender, EventArgs e)
        {

            String strFilters = "You are filtering your search on: ";
            if(chkFootwear.Checked)
            {
                strFilters = strFilters + "Footwear ";
            }
            if (chkClothing.Checked)
            {
                strFilters = strFilters + "Clothing ";
            }
            if (chkTennisEquipment.Checked)
            {
                strFilters = strFilters + "Tennis Equipment ";
            }
            if (chkSoccerEquipment.Checked)
            {
                strFilters = strFilters + "Soccer Equipment ";
            }
            lblFilters.Text = strFilters;

        }

    }

}