﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class ListBoxClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void libSupplier_SelectedIndexChanged(object sender, EventArgs e)
        {

            lblSupplierIndex.Text = libSupplier.SelectedIndex.ToString();
            lblSupplierValue.Text = libSupplier.SelectedItem.Value;
            lblSupplierText.Text = libSupplier.SelectedItem.Text;

        }

    }

}