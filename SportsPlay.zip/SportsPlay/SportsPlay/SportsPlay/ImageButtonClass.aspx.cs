﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class ImageButtonClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnDisplayDescription_Click(object sender, ImageClickEventArgs e)
        {

            lblDescription.Text = "Prince Textreme Warrior 100";

        }

    }

}