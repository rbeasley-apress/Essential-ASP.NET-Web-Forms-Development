﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class FileUploadClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {

            if (fiuImage.HasFile)
            {
                String strPath = Request.PhysicalApplicationPath + "Images\\" + fiuImage.FileName;
                fiuImage.SaveAs(strPath);
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Product image was successfully uploaded.";
            }
            else
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "No product image was selected. Please select a file and try again.";
            }

        }

    }

}
