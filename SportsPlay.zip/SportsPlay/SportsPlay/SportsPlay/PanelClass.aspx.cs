﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class PanelClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void radBillingAddress_CheckedChanged(object sender, EventArgs e)
        {

            TogglePanel();

        }

        protected void radShippingAddress_CheckedChanged(object sender, EventArgs e)
        {

            TogglePanel();

        }

        private void TogglePanel()
        {

            if (panBillingAddress.Visible)
            {
                panBillingAddress.Visible = false;
                panShippingAddress.Visible = true;
            }
            else
            {
                panBillingAddress.Visible = true;
                panShippingAddress.Visible = false;
            }

        }

        protected void btnSaveBillingAddress_Click(object sender, EventArgs e)
        {

        }

        protected void btnSaveShippingAddress_Click(object sender, EventArgs e)
        {

        }

    }

}