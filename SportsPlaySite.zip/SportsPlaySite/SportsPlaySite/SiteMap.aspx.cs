﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlaySite
{
    public partial class SiteMap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // Populate the master page fields.
            this.Master.User = Session["strFullName"].ToString();
            this.Master.PageTitle = "Site Map";
            this.Master.MessageForeColor = System.Drawing.Color.Green;
            this.Master.Message = "Please use the site map below to navigate our website.";
            this.Master.LogText = "[Logout]";

        }
    }
}