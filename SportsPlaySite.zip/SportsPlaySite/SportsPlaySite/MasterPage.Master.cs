﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlaySite
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {

        public String User
        {
            set { lblUser.Text = value; }
        }

        public String PageTitle
        {
            set { lblPageTitle.Text = value; }
        }

        public System.Drawing.Color MessageForeColor
        {
            set { lblMessage.ForeColor = value; }
        }

        public String Message
        {
            set { lblMessage.Text = value; }
        }

        public String LogText
        {
            set { btnLog.Text = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            // Set the server name.
            lblServerName.Text = Request.ServerVariables["Server_Name"];

            // Set the version number.
            lblVersion.Text = "1.00";

            // Set the date.
            lblDate.Text = DateTime.Today.ToShortDateString();

            // Set the contact.
            lblContact.Text = "If you have questions or experience problems with this website, please contact....";

        }

    }

}