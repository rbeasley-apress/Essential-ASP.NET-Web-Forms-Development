﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlaySite
{
    public partial class Options : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // Populate the master page fields.
            this.Master.User = Session["strFullName"].ToString();
            this.Master.PageTitle = "Options";
            this.Master.MessageForeColor = System.Drawing.Color.Green;
            this.Master.Message = "Please choose from the options below.";
            this.Master.LogText = "[Logout]";

        }
    }
}