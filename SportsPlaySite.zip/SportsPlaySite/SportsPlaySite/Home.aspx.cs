﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlaySite
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // Populate the master page fields.
            this.Master.User = "*";
            this.Master.PageTitle = "Home";
            this.Master.MessageForeColor = System.Drawing.Color.Green;
            this.Master.Message = "Please click [Login] to login to the system.";
            this.Master.LogText = "[Login]";

        }

    }

}