﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class ModalPopupExtenderClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {

            lblShipper.ForeColor = System.Drawing.Color.Green;
            if (radUSPS.Checked)
            {
                lblShipper.Text = "You have selected USPS as your shipper.";
            }
            else if (radUPS.Checked)
            {
                lblShipper.Text = "You have selected UPS as your shipper.";
            }
            else if (radFedEx.Checked)
            {
                lblShipper.Text = "You have selected FedEx as your shipper.";
            }
            else
            {
                lblShipper.ForeColor = System.Drawing.Color.Red;
                lblShipper.Text = "You have not selected a shipper. Please try again.";
            }

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

            lblShipper.ForeColor = System.Drawing.Color.Red;
            lblShipper.Text = "You have not selected a shipper. Please try again.";

        }

    }

}