﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsPlay
{
    public partial class AjaxFileUploadClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void afuImage_UploadComplete(object sender, AjaxControlToolkit.AjaxFileUploadEventArgs e)
        {

            // Save the file to the specified location.
            String strFilePath = Request.PhysicalApplicationPath + "Images\\" + e.FileName;
            afuImage.SaveAs(strFilePath);

        }

    }

}